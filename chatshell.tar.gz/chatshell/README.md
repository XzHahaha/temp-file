# ChatShell 聊天壳

自部署的 AI 陪伴聊天应用：网页版 PWA（Windows / 安卓 / iPhone 浏览器通用），支持导入 **SillyTavern 角色卡**（V1/V2/V3 PNG 与 JSON）、流式对话、重试多备选（swipe）、**记忆池**、**自定义主题**、**主动消息推送**、每日悄悄话、陪伴天数统计。

参考「YourChat 制作教程」的架构思路：客户端只连你自己的服务器，**API 密钥只存在服务端**，每个会话上下文隔离。

## 功能

- **角色卡导入**：把酒馆角色卡 PNG/JSON 拖进「我的 → 导入角色卡」，自动解析人设、开场白（含备用开场白）、示例对话、世界书关键词注入，卡图作头像
- **聊天**：SSE 流式打字机、随时停止、重新生成（新备选）、左右切换备选（swipe）、编辑/删除消息、会话重命名/清空重开/删除
- **记忆池**：手动记一条，或让 AI 从对话自动总结（每聊 N 条自动触发，间隔可调）；生效中的记忆每次对话都会注入
- **主动消息**：设定时间（或每天随机时刻）让 TA 主动发消息给你，走 Web Push 手机通知，点通知直接进聊天
- **自定义主题**：黄昏 / 深夜 / 樱雨 / 松间 / 晴空 五套预设，背景风景颜色随主题联动；可上传自己的照片做背景
- **首页仪表盘**：时段问候、Day 天数、Monthly Anniversary 进度环、共同记忆/聊过的话统计、Today's Whisper（AI 生成的一句悄悄话）
- **多端同时在线**：Windows 和安卓同时登录互不顶号
- **安全**：密码登录（scrypt 哈希）、登录限速、HttpOnly Cookie、密钥永不下发到前端

## 本地运行

需要 Node.js 22.12+。

```bash
npm install
npm start          # 默认 http://localhost:3000，PORT 环境变量可改
```

首次打开网页会要求设置访问密码。然后到「我的 → 模型 API」填：

- **接口地址**：任何 OpenAI 兼容接口，如 `https://api.deepseek.com/v1`
- **API Key**：你的 key（只存服务器）
- **模型名称**：如 `deepseek-chat`

没有 key 也可以先玩：`npm run mock` 启动本地模拟模型（端口 8788），接口地址填 `http://127.0.0.1:8788/v1`。`npm run makecard` 会生成一张测试角色卡（test/test-card.png）。

## 部署到 VPS（Ubuntu）

```bash
# 1. 装 Node 22（已装可跳过）
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs

# 2. 上传代码并解压到 /opt/chatshell 后：
cd /opt/chatshell
npm install --omit=dev

# 3. systemd 常驻（默认监听 80 端口）
sudo cp deploy/chatshell.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now chatshell
```

> 80 端口原因：手机流量访问非标端口（如 3000）的 HTTP 常被运营商代理拦截，出现 502。

### 强烈建议：配置 HTTPS（一句话的事）

**Web Push 通知和 PWA「安装到主屏幕」都要求 HTTPS**。没有域名也能 5 分钟搞定——用免费的 DuckDNS 子域：

1. 到 [duckdns.org](https://www.duckdns.org) 用 GitHub 账号登录，建一个子域（如 `mychat.duckdns.org`），填上你的 VPS IP
2. VPS 上用 acme.sh 签证书（DNS 方式，Token 在 DuckDNS 页面顶部）：

```bash
apt install -y socat
curl https://get.acme.sh | sh -s email=my@example.com
~/.acme.sh/acme.sh --issue --dns dns_duckdns -d mychat.duckdns.org --duckdns-token 你的TOKEN
~/.acme.sh/acme.sh --install-cert -d mychat.duckdns.org \
  --key-file /opt/chatshell/cert.key --fullchain-file /opt/chatshell/cert.crt
```

3. 让 Node 直接跑 HTTPS：在 `/etc/systemd/system/chatshell.service` 的 `[Service]` 里加两行后重启：

```ini
Environment=SSL_CERT=/opt/chatshell/cert.crt
Environment=SSL_KEY=/opt/chatshell/cert.key
```

4. 手机打开 `https://mychat.duckdns.org` → 「我的 → 主动消息 → 开启手机通知」即可

> 在 server.js 同目录放一个 `entry-https.js` 不必要：服务端已内置对 SSL_CERT/SSL_KEY 环境变量的支持（见下）。

### 已有域名的话（推荐，自动续期）

```bash
sudo apt-get install -y caddy
# /etc/caddy/Caddyfile:
#   chat.example.com {
#       reverse_proxy 127.0.0.1:8080
#   }
# 把 chatshell.service 的 PORT 改成 8080（80/443 让给 Caddy）
sudo systemctl reload caddy
```

## 安卓安装为 App + 开启主动消息

1. **Chrome 打开你的 HTTPS 地址**，登录
2. 菜单 → 「添加到主屏幕/安装应用」→ 桌面出现图标，全屏运行
3. 「我的 → 主动消息」：打开定时开关、设时间、选角色 → 点「开启手机通知」允许通知权限
4. 到点后 TA 会直接发系统通知给你，点开就是聊天界面

## 数据与备份

所有数据都在 `data/` 目录（SQLite 数据库 + 头像 + 背景图），备份这个目录即可。删除角色会连带删除其会话与记忆。

## 目录结构

```
server.js            入口（HTTPS 由 SSL_CERT/SSL_KEY 环境变量开启）
src/db.js            SQLite（node:sqlite，零编译依赖）
src/auth.js          密码登录 / 多端 token
src/cards.js         角色卡解析（PNG tEXt/zTXt/iTXt + JSON，V1/V2/V3）
src/prompts.js       Prompt 组装 + 宏替换 + 世界书注入 + 记忆池注入
src/llm.js           OpenAI 兼容流式客户端
src/push.js          主动消息生成 + Web Push 发送 + 调度器
src/routes.js        REST + SSE 路由
public/              前端 SPA + PWA
test/mock-llm.js     本地模拟模型（无 key 全流程测试）
test/make-card.js    生成测试角色卡
deploy/              systemd / Docker / Caddy
```

## 已知边界

- 世界书采用「关键词扫描最近 4 条消息 + 常驻条目」的简化策略，不含酒馆的深度插入位置/递归扫描等高级规则
- 主动消息的推送依赖浏览器推送服务（Android Chrome 走 Google FCM；国内部分定制浏览器可能不支持）
- 不支持酒馆的正则脚本、TTS、多人群聊（本期范围外）
