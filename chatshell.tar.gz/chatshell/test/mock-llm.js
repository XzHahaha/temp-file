// 本地模拟 OpenAI 兼容接口（SSE 流式），用于无真实 key 的全流程测试
// 用法：node test/mock-llm.js  （默认监听 8788，接口地址填 http://127.0.0.1:8788/v1）
const http = require('node:http');

const PORT = Number(process.env.MOCK_PORT) || 8788;

function buildReply(messages) {
  const system = messages.find((m) => m.role === 'system')?.content || '';
  const lastUser = [...messages].reverse().find((m) => m.role === 'user')?.content || '';

  if (system.includes('记忆管理器')) {
    return '- 用户喜欢在深夜聊天，是个夜猫子\n- 用户养了一只叫煤球的橘猫\n- 用户正在测试聊天壳的记忆池功能';
  }
  if (system.includes('悄悄话')) {
    return '*用尾巴尖轻轻碰了碰你的手背* 今天的晚霞很好看……你要是也能看到就好了。';
  }

  const flags = [];
  if (system.includes('【记忆池】')) flags.push('记忆池已注入');
  if (system.includes('【补充设定】')) flags.push('世界书已注入');
  const reply = `*耳朵微微一动* 唔……「${(lastUser || '').slice(0, 30)}」吗？让小满想想。\n*尾巴尖卷了卷* ${flags.length ? `（${flags.join('，')}）` : ''}好吧，就陪你聊聊这个。今晚想吃什么？`;

  const sysLen = system.replace(/\s/g, '').length;
  const hasChar = system.includes('小满');
  return reply + `\n\n*(mock · system ${sysLen} 字${hasChar ? ' · 含角色设定' : ' · 缺角色设定'})*`;
}

const server = http.createServer((req, res) => {
  if (!req.url.includes('/chat/completions')) {
    res.writeHead(404).end('not found');
    return;
  }
  let body = '';
  req.on('data', (c) => { body += c; });
  req.on('end', () => {
    const data = JSON.parse(body || '{}');
    const reply = buildReply(data.messages || []);

    if (!data.stream) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ choices: [{ message: { role: 'assistant', content: reply }, finish_reason: 'stop' }] }));
      return;
    }

    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
    });
    res.write(`data: ${JSON.stringify({ choices: [{ delta: { role: 'assistant' } }] })}\n\n`);

    // 按小块流出，模拟打字机
    const pieces = reply.match(/[\s\S]{1,8}/g) || [];
    let i = 0;
    const timer = setInterval(() => {
      if (i >= pieces.length) {
        clearInterval(timer);
        res.write(`data: ${JSON.stringify({ choices: [{ delta: {}, finish_reason: 'stop' }] })}\n\n`);
        res.write('data: [DONE]\n\n');
        res.end();
        return;
      }
      res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: pieces[i++] } }] })}\n\n`);
    }, 40);
  });
});

server.listen(PORT, () => {
  console.log(`Mock LLM 已启动：http://127.0.0.1:${PORT}/v1/chat/completions`);
  console.log('在聊天壳「我的 → 模型 API」里把接口地址填成上面这个即可测试。');
});
