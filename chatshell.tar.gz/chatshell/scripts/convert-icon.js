// 把用户提供的图片转成 PWA 图标（居中裁正方形，输出 512/192 PNG）
const Jimp = require('jimp');
const path = require('node:path');

const SRC = 'C:\\Users\\Administrator\\Documents\\xwechat_files\\wxid_mtrdccoo37gj12_fcbb\\temp\\RWTemp\\2026-09\\9e20f478899dc29eb19741386f9343c8\\4ec378e98a93124dcc3f0729b4be5493.jpg';
const OUT_DIR = path.join(__dirname, '..', 'public', 'icons');

(async () => {
  const img = await Jimp.read(SRC);
  const side = Math.min(img.getWidth(), img.getHeight());
  const sx = Math.floor((img.getWidth() - side) / 2);
  const sy = Math.floor((img.getHeight() - side) / 2);
  img.crop(sx, sy, side, side);

  for (const size of [512, 192]) {
    const out = img.clone().resize(size, size, Jimp.RESIZE_BICUBIC);
    await out.quality(95).writeAsync(path.join(OUT_DIR, `icon-${size}.png`));
    console.log(`icon-${size}.png OK`);
  }
})();
