# 把用户提供的图片转成 PWA 图标（居中裁正方形，输出 512/192 PNG）
Add-Type -AssemblyName System.Drawing

$src = 'C:\Users\Administrator\Documents\xwechat_files\wxid_mtrdccoo37gj12_fcbb\temp\RWTemp\2026-09\9e20f478899dc29eb19741386f9343c8\4ec378e98a93124dcc3f0729b4be5493.jpg'
$outDir = 'C:\Users\Administrator\.zcode\workspace\default\chatshell\public\icons'

$img = [System.Drawing.Image]::FromFile($src)
$side = [Math]::Min($img.Width, $img.Height)
$sx = [int](($img.Width - $side) / 2)
$sy = [int](($img.Height - $side) / 2)

foreach ($size in 512, 192) {
  $bmp = New-Object System.Drawing.Bitmap($size, $size)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
  $dstRect = New-Object System.Drawing.Rectangle(0, 0, $size, $size)
  $srcRect = New-Object System.Drawing.Rectangle($sx, $sy, $side, $side)
  $g.DrawImage($img, $dstRect, $srcRect, [System.Drawing.GraphicsUnit]::Pixel)
  $g.Dispose()
  $bmp.Save("$outDir\icon-$size.png", [System.Drawing.Imaging.ImageFormat]::Png)
  $bmp.Dispose()
  Write-Host "icon-$size.png OK"
}
$img.Dispose()
