// 生成 PWA 图标：渐变底 + 白色聊天气泡
const fs = require('node:fs');
const path = require('node:path');
const { encodePng } = require('./pngmin');

function mix(c1, c2, t) {
  return [
    Math.round(c1[0] + (c2[0] - c1[0]) * t),
    Math.round(c1[1] + (c2[1] - c1[1]) * t),
    Math.round(c1[2] + (c2[2] - c1[2]) * t),
  ];
}

function roundedRectDist(x, y, cx, cy, w, h, r) {
  const dx = Math.abs(x - cx) - (w / 2 - r);
  const dy = Math.abs(y - cy) - (h / 2 - r);
  return Math.hypot(Math.max(dx, 0), Math.max(dy, 0)) - r;
}

function iconPixel(size) {
  const c1 = [79, 70, 229];   // indigo
  const c2 = [139, 92, 246];  // violet
  return (x, y) => {
    const u = (x + y) / (2 * size);
    let color = mix(c1, c2, u);

    const s = size / 512;
    const bubble = roundedRectDist(x, y, size / 2, size * 0.46, size * 0.56, size * 0.42, size * 0.12);
    const inBubble = bubble <= 0;
    // 气泡小尾巴（左下小三角形）
    const tx = size * 0.38, ty = size * 0.70;
    const inTail = y >= ty && y <= ty + size * 0.12 * s * 8 && x >= tx - (y - ty) && x <= tx + size * 0.10;
    if (inBubble || inTail) color = [238, 242, 255];
    // 三个点
    for (let i = -1; i <= 1; i++) {
      const dx = x - (size / 2 + i * size * 0.14);
      const dy = y - size * 0.46;
      if (dx * dx + dy * dy <= (size * 0.045) ** 2) color = [79, 70, 229];
    }
    return color;
  };
}

const outDir = path.join(__dirname, '..', 'public', 'icons');
fs.mkdirSync(outDir, { recursive: true });
for (const size of [192, 512]) {
  const png = encodePng(size, size, iconPixel(size));
  fs.writeFileSync(path.join(outDir, `icon-${size}.png`), png);
  console.log(`已生成 icon-${size}.png`);
}
