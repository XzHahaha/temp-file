// 生成 PWA 图标：暖米黄昏底 + 墨绿聊天气泡 + 月牙
const fs = require('node:fs');
const path = require('node:path');
const { encodePng } = require('./pngmin');

const BG1 = [246, 238, 221];  // 暖米
const BG2 = [233, 217, 189];  // 淡杏
const GREEN = [47, 74, 58];   // 墨绿（同应用 whisper 卡）
const CREAM = [243, 234, 216]; // 米白（点）
const MOON = [232, 168, 101]; // 暖橙月牙

function mix(c1, c2, t) {
  return [
    Math.round(c1[0] + (c2[0] - c1[0]) * t),
    Math.round(c1[1] + (c2[1] - c1[1]) * t),
    Math.round(c1[2] + (c2[2] - c1[2]) * t),
  ];
}

function roundedRectDist(x, y, cx, cy, w, h, r) {
  const dx = Math.abs(x - cx) - (w / 2 - r);
  const dy = Math.abs(y - cy) - (h / 2 - r);
  return Math.hypot(Math.max(dx, 0), Math.max(dy, 0)) - r;
}

function iconPixel(size) {
  return (x, y) => {
    let color = mix(BG1, BG2, y / size);

    const s = size / 512;

    // 墨绿气泡（圆角矩形）
    const bubble = roundedRectDist(x, y, size * 0.5, size * 0.46, size * 0.56, size * 0.42, size * 0.13);
    // 气泡尾巴：左下角小尖角
    const tailX = size * 0.33, tailY = size * 0.60;
    const inTail = y >= tailY && y <= tailY + size * 0.16 && x >= tailX - (y - tailY) * 0.85 && x <= tailX + size * 0.10;
    if (bubble <= 0 || inTail) color = GREEN;

    // 三个米白点
    for (let i = -1; i <= 1; i++) {
      const dx = x - (size * 0.5 + i * size * 0.14);
      const dy = y - size * 0.46;
      if (dx * dx + dy * dy <= (size * 0.042) ** 2) color = CREAM;
    }

    // 右上角月牙：大圆减小圆
    const mcx = size * 0.80, mcy = size * 0.155, mr = size * 0.085;
    const d1 = Math.hypot(x - mcx, y - mcy);
    const d2 = Math.hypot(x - (mcx - size * 0.045), y - (mcy - size * 0.02));
    if (d1 <= mr && d2 >= mr * 0.82) color = MOON;

    return color;
  };
}

const outDir = path.join(__dirname, '..', 'public', 'icons');
fs.mkdirSync(outDir, { recursive: true });
for (const size of [192, 512]) {
  const png = encodePng(size, size, iconPixel(size));
  fs.writeFileSync(path.join(outDir, `icon-${size}.png`), png);
  console.log(`已生成 icon-${size}.png`);
}
