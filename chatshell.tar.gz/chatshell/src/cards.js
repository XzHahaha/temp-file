const zlib = require('node:zlib');

// SillyTavern 角色卡：PNG 的 tEXt/zTXt 块中以 base64 内嵌 JSON
// V2 关键字为 chara，V3 为 ccv3（优先），旧 V1 同样在 chara 但字段在根层级
const PNG_SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

function isPng(buffer) {
  return buffer && buffer.length > 8 && buffer.subarray(0, 8).equals(PNG_SIGNATURE);
}

function decodeBase64Utf8(text) {
  return Buffer.from(text, 'base64').toString('utf8');
}

function extractTextChunks(buffer) {
  const found = {}; // keyword -> 解 base64 后的 JSON 字符串
  let off = 8;
  while (off + 12 <= buffer.length) {
    const len = buffer.readUInt32BE(off);
    const type = buffer.toString('ascii', off + 4, off + 8);
    const data = buffer.subarray(off + 8, off + 8 + len);
    try {
      if (type === 'tEXt') {
        const nul = data.indexOf(0);
        if (nul > 0) {
          const keyword = data.toString('latin1', 0, nul);
          found[keyword] = decodeBase64Utf8(data.toString('latin1', nul + 1));
        }
      } else if (type === 'zTXt') {
        const nul = data.indexOf(0);
        if (nul > 0 && data[nul + 1] === 0) {
          const keyword = data.toString('latin1', 0, nul);
          const text = zlib.inflateSync(data.subarray(nul + 2)).toString('latin1');
          found[keyword] = decodeBase64Utf8(text);
        }
      } else if (type === 'iTXt') {
        const nul = data.indexOf(0);
        if (nul > 0) {
          const keyword = data.toString('latin1', 0, nul);
          const compFlag = data[nul + 1];
          let rest = data.subarray(nul + 3);
          const langEnd = rest.indexOf(0);
          rest = rest.subarray(langEnd + 1);
          const transEnd = rest.indexOf(0);
          let textBuf = rest.subarray(transEnd + 1);
          if (compFlag === 1) textBuf = zlib.inflateSync(textBuf);
          found[keyword] = textBuf.toString('utf8');
        }
      }
    } catch { /* 跳过无法解压/解码的块 */ }
    off += 12 + len;
    if (type === 'IEND') break;
  }
  return found;
}

function normalizeBook(book) {
  if (!book || typeof book !== 'object') return null;
  let rawEntries = book.entries;
  if (!rawEntries) return null;
  if (!Array.isArray(rawEntries) && typeof rawEntries === 'object') {
    rawEntries = Object.values(rawEntries); // ST 内部世界书用数字下标对象
  }
  if (!Array.isArray(rawEntries)) return null;
  const entries = rawEntries
    .filter((e) => e && typeof e === 'object' && typeof e.content === 'string' && e.content.trim())
    .map((e) => {
      // V2 规范字段为 keys/enabled/insertion_order；ST 导出常见变体为 key/disable/order
      const keys = Array.isArray(e.keys) ? e.keys : (Array.isArray(e.key) ? e.key : []);
      return {
        keys: keys.map((k) => String(k).toLowerCase().trim()).filter(Boolean),
        content: e.content.trim(),
        constant: !!e.constant,
        enabled: e.enabled !== undefined ? !!e.enabled : !e.disable,
        order: Number.isFinite(Number(e.insertion_order ?? e.order)) ? Number(e.insertion_order ?? e.order) : 100,
      };
    })
    .filter((e) => e.enabled);
  return entries.length ? { name: String(book.name || ''), entries } : null;
}

function normalizeCard(json) {
  if (!json || typeof json !== 'object') throw new Error('角色卡 JSON 无效');
  const data = (json.data && typeof json.data === 'object') ? json.data : json;
  const specVer = String(json.spec_version || json.spec || '');
  const spec = specVer.startsWith('3') ? 'v3' : (specVer.startsWith('2') || json.spec === 'chara_card_v2' ? 'v2' : 'v1');
  const s = (v) => (typeof v === 'string' ? v.trim() : '');

  const card = {
    spec,
    name: s(data.name) || '未命名角色',
    nickname: s(data.nickname),
    description: s(data.description),
    personality: s(data.personality),
    scenario: s(data.scenario),
    first_mes: s(data.first_mes),
    alternate_greetings: Array.isArray(data.alternate_greetings)
      ? data.alternate_greetings.filter((x) => typeof x === 'string' && x.trim())
      : [],
    mes_example: s(data.mes_example),
    system_prompt: s(data.system_prompt),
    post_history_instructions: s(data.post_history_instructions),
    creator_notes: s(data.creator_notes),
    creator: s(data.creator),
    character_version: s(data.character_version),
    tags: Array.isArray(data.tags) ? data.tags.map(String) : [],
    character_book: normalizeBook(data.character_book),
  };
  if (!card.description && !card.first_mes && !card.personality) {
    throw new Error('角色卡缺少 description / first_mes / personality 等关键字段，无法使用');
  }
  return card;
}

function parseCardFromPng(buffer) {
  const chunks = extractTextChunks(buffer);
  const raw = chunks.ccv3 || chunks.chara;
  if (!raw) throw new Error('PNG 中没有找到角色卡数据（缺少 chara/ccv3 文本块）');
  let json;
  try {
    json = JSON.parse(raw);
  } catch {
    throw new Error('角色卡内嵌 JSON 解析失败，文件可能损坏');
  }
  return normalizeCard(json);
}

function parseCardFromJson(text) {
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error('JSON 文件解析失败');
  }
  return normalizeCard(json);
}

module.exports = { isPng, parseCardFromPng, parseCardFromJson, normalizeCard };
