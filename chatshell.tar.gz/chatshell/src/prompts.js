const DEFAULT_SYSTEM = [
  '你在角色扮演中扮演 {{char}}，与 {{user}} 进行一对一的沉浸式对话。',
  '- 始终保持角色一致，以 {{char}} 的身份、语气和思维方式回应',
  '- 回应生动自然，动作与心理描写用*星号*包裹，台词用引号',
  '- 不要代替 {{user}} 说话、思考或行动',
  '- 不要跳出角色，不要以AI助手自居，不要复述设定原文',
].join('\n');

const WI_SCAN_DEPTH = 4; // 世界书关键词扫描最近几条消息

function substituteMacros(text, { char, user }) {
  if (!text) return '';
  const now = new Date();
  return String(text)
    .replace(/\{\{char\}\}/gi, char)
    .replace(/\{\{user\}\}/gi, user)
    .replace(/\{\{time\}\}/gi, now.toLocaleTimeString('zh-CN', { hour12: false }))
    .replace(/\{\{date\}\}/gi, now.toLocaleDateString('zh-CN'));
}

function buildWorldInfo(card, recentMessages) {
  const book = card.character_book;
  if (!book) return [];
  const scanText = recentMessages.map((m) => (m.content || '').toLowerCase()).join('\n');
  return book.entries
    .filter((e) => e.constant || e.keys.some((k) => k && scanText.includes(k)))
    .sort((a, b) => a.order - b.order)
    .map((e) => e.content);
}

// history: [{role:'user'|'assistant', content}]，content 取的是各消息当前选中的 swipe
// memories: [{content}]，记忆池中启用的长期记忆
function buildMessages({ card, settings, history, memories = [] }) {
  const charName = card.nickname || card.name;
  const userName = settings.persona_name || 'User';
  const mac = (t) => substituteMacros(t, { char: charName, user: userName });

  const blocks = [];
  const sys = card.system_prompt ? mac(card.system_prompt) : mac(DEFAULT_SYSTEM);
  blocks.push(sys);
  if (card.description) blocks.push(`【角色设定】\n${mac(card.description)}`);
  if (card.personality) blocks.push(`【性格特点】\n${mac(card.personality)}`);
  if (card.scenario) blocks.push(`【当前场景】\n${mac(card.scenario)}`);

  const persona = (settings.persona_description || '').trim();
  if (persona) blocks.push(mac(`【{{user}} 的身份】\n${userName} 的人设：${persona}`));

  const memoryLines = memories.filter((m) => m && m.content && m.content.trim()).map((m) => `- ${m.content.trim()}`);
  if (memoryLines.length) blocks.push(mac(`【记忆池：你与 ${userName} 的长期记忆，始终保持一致】\n${memoryLines.join('\n')}`));

  const examples = mac(card.mes_example || '').replace(/<START>/gi, '\n———\n').trim();
  if (examples) blocks.push(`【对话示例（仅风格参考，不要照抄内容）】\n${examples}`);

  const wi = buildWorldInfo(card, history.slice(-WI_SCAN_DEPTH));
  if (wi.length) blocks.push(`【补充设定】\n${wi.map(mac).join('\n')}`);

  const messages = [{ role: 'system', content: blocks.join('\n\n') }];

  const limit = Math.max(2, Number(settings.context_messages) || 40);
  for (const m of history.slice(-limit)) {
    messages.push({
      role: m.role,
      name: m.role === 'assistant' ? charName : userName,
      content: mac(m.content),
    });
  }

  if (card.post_history_instructions) {
    messages.push({ role: 'system', content: mac(card.post_history_instructions) });
  }
  return messages;
}

module.exports = { buildMessages, substituteMacros, DEFAULT_SYSTEM };
