const crypto = require('node:crypto');
const { getSetting, setSetting } = require('./db');

const COOKIE_NAME = 'cs_token';
const COOKIE_MAX_AGE = 90 * 24 * 3600;
const MAX_ATTEMPTS = 5;
const LOCK_MS = 60 * 1000;

const attempts = new Map(); // ip -> { count, until }

function sha256(text) {
  return crypto.createHash('sha256').update(text).digest('hex');
}

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function isConfigured() {
  return !!getSetting('password_hash');
}

function setupPassword(password) {
  if (isConfigured()) throw new Error('密码已初始化过，请直接登录');
  const salt = crypto.randomBytes(16).toString('hex');
  setSetting('password_salt', salt);
  setSetting('password_hash', hashPassword(password, salt));
}

function verifyPassword(password) {
  const hash = getSetting('password_hash');
  const salt = getSetting('password_salt');
  if (!hash || !salt) return false;
  const calc = Buffer.from(hashPassword(password, salt), 'hex');
  const stored = Buffer.from(hash, 'hex');
  return calc.length === stored.length && crypto.timingSafeEqual(calc, stored);
}

function clientIp(req) {
  const fwd = req.headers['x-forwarded-for'];
  if (typeof fwd === 'string' && fwd.trim()) return fwd.split(',')[0].trim();
  return req.socket.remoteAddress || 'unknown';
}

function isLocked(ip) {
  const rec = attempts.get(ip);
  return !!rec && rec.until > Date.now();
}

function registerFailure(ip) {
  const rec = attempts.get(ip) || { count: 0, until: 0 };
  rec.count += 1;
  if (rec.count >= MAX_ATTEMPTS) {
    rec.until = Date.now() + LOCK_MS;
    rec.count = 0;
  }
  attempts.set(ip, rec);
}

function clearFailures(ip) {
  attempts.delete(ip);
}

function loadTokens() {
  try { return JSON.parse(getSetting('session_tokens', '[]')); } catch { return []; }
}

function saveTokens(tokens) {
  setSetting('session_tokens', JSON.stringify(tokens.slice(-20)));
}

function issueToken(res) {
  const token = crypto.randomBytes(32).toString('hex');
  const tokens = loadTokens();
  tokens.push(sha256(token));
  saveTokens(tokens);
  res.setHeader('Set-Cookie',
    `${COOKIE_NAME}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${COOKIE_MAX_AGE}`);
}

function logout(req, res) {
  const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
  if (token) saveTokens(loadTokens().filter((t) => t !== sha256(token)));
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
}

function parseCookies(header) {
  const out = {};
  for (const part of String(header || '').split(';')) {
    const idx = part.indexOf('=');
    if (idx > 0) out[part.slice(0, idx).trim()] = decodeURIComponent(part.slice(idx + 1).trim());
  }
  return out;
}

function authRequired(req, res, next) {
  const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
  if (token && loadTokens().includes(sha256(token))) return next();
  res.status(401).json({ error: '未登录或登录已过期' });
}

module.exports = {
  isConfigured, setupPassword, verifyPassword, issueToken, logout,
  authRequired, clientIp, isLocked, registerFailure, clearFailures,
};
