// OpenAI 兼容 /chat/completions 流式客户端
async function* streamCompletion(cfg, messages, signal) {
  const base = String(cfg.api_base || '').replace(/\/+$/, '');
  if (!base) throw new Error('尚未配置模型 API 地址，请先到「设置」里填写');

  let res;
  try {
    res = await fetch(base + '/chat/completions', {
      method: 'POST',
      signal,
      headers: {
        'Content-Type': 'application/json',
        ...(cfg.api_key ? { Authorization: `Bearer ${cfg.api_key}` } : {}),
      },
      body: JSON.stringify({
        model: cfg.model || 'gpt-3.5-turbo',
        messages,
        temperature: cfg.temperature ?? 0.8,
        stream: true,
      }),
    });
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    throw new Error(`无法连接模型接口（${base}）：${e.message}`);
  }

  if (!res.ok) {
    let detail = '';
    try { detail = (await res.text()).slice(0, 400); } catch { /* ignore */ }
    throw new Error(`模型接口返回 ${res.status}：${detail || res.statusText}`);
  }

  const contentType = res.headers.get('content-type') || '';
  if (!contentType.includes('event-stream')) {
    // 个别中转不支持 stream，退回一次性 JSON
    const j = await res.json().catch(() => null);
    const text = j && j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
    if (text) yield text;
    return;
  }

  const decoder = new TextDecoder();
  let buf = '';
  for await (const chunk of res.body) {
    buf += decoder.decode(chunk, { stream: true });
    let nl;
    while ((nl = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, nl).trim();
      buf = buf.slice(nl + 1);
      if (!line.startsWith('data:')) continue;
      const payload = line.slice(5).trim();
      if (payload === '[DONE]') return;
      try {
        const j = JSON.parse(payload);
        const delta = j.choices && j.choices[0] && j.choices[0].delta;
        if (delta && typeof delta.content === 'string' && delta.content) yield delta.content;
      } catch { /* 忽略半行/心跳等非JSON帧 */ }
    }
  }
}

module.exports = { streamCompletion };
