const express = require('express');
const fs = require('node:fs');
const path = require('node:path');
const multer = require('multer');
const { db, getSetting, setSetting, rowToMessage, AVATAR_DIR } = require('./db');
const auth = require('./auth');
const { isPng, parseCardFromPng, parseCardFromJson } = require('./cards');
const { buildMessages, substituteMacros } = require('./prompts');
const { streamCompletion } = require('./llm');
const push = require('./push');

const router = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 100 * 1024 * 1024 },
});

// 同一会话同时只允许一次生成
const generating = new Set();

/* ---------------- 主动推送 ---------------- */

router.get('/push/key', auth.authRequired, (req, res) => {
  res.json({ publicKey: push.vapidKeys().publicKey });
});

router.post('/push/subscribe', auth.authRequired, (req, res) => {
  const sub = (req.body || {}).subscription;
  const characterId = Number((req.body || {}).character_id);
  if (!sub || !sub.endpoint || !sub.keys || !sub.keys.p256dh || !sub.keys.auth) {
    return res.status(400).json({ error: '订阅数据无效' });
  }
  const char = db.prepare('SELECT id FROM characters WHERE id = ?').get(characterId);
  db.prepare(`INSERT INTO push_subs(endpoint, p256dh, auth, character_id, created_at) VALUES(?,?,?,?,?)
              ON CONFLICT(endpoint) DO UPDATE SET p256dh = excluded.p256dh, auth = excluded.auth, character_id = excluded.character_id`)
    .run(sub.endpoint, sub.keys.p256dh, sub.keys.auth, char ? char.id : null, Date.now());
  res.json({ ok: true });
});

router.post('/push/unsubscribe', auth.authRequired, (req, res) => {
  const endpoint = (req.body || {}).endpoint;
  if (endpoint) db.prepare('DELETE FROM push_subs WHERE endpoint = ?').run(endpoint);
  res.json({ ok: true });
});

// 立即推一条测试通知
router.post('/push/test', auth.authRequired, async (req, res) => {
  try {
    const charId = Number((req.body || {}).character_id);
    const char = db.prepare('SELECT * FROM characters WHERE id = ?').get(charId);
    if (!char) return res.status(404).json({ error: '角色不存在' });
    const card = JSON.parse(char.card_json);
    push.sendToCharacterSubs(char.id, `${card.nickname || card.name}（测试）`, '通知已打通！以后 TA 会主动来找你聊天的。');
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 手动触发一次主动消息（不推送通知，只生成消息进会话）
router.post('/characters/:id/proactive', auth.authRequired, async (req, res) => {
  try {
    await push.fireProactive(Number(req.params.id));
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/* ---------------- 主题 ---------------- */

const THEME_DIR = path.join(require('./db').DATA_DIR, 'themes');

const THEME_PRESETS = ['dusk', 'night', 'sakura', 'pine', 'sky'];

// 主题对登录页也生效，此接口免登录；bg: 'image' | 'video' | null
function themeState() {
  const bg = getSetting('theme_bg', '');
  const bgVideo = getSetting('theme_bg_video', '');
  return { preset: getSetting('theme_preset', 'dusk'), bg: bgVideo ? 'video' : (bg ? 'image' : null) };
}

router.get('/theme', (req, res) => {
  res.json(themeState());
});

router.get('/theme/bg', (req, res) => {
  const file = getSetting('theme_bg', '');
  if (!file) return res.status(404).end();
  res.setHeader('Cache-Control', 'public, max-age=300');
  res.sendFile(path.join(THEME_DIR, file));
});

router.get('/theme/bg-video', (req, res) => {
  const file = getSetting('theme_bg_video', '');
  if (!file) return res.status(404).end();
  res.setHeader('Cache-Control', 'public, max-age=300');
  res.setHeader('Accept-Ranges', 'bytes');
  res.sendFile(path.join(THEME_DIR, file));
});

router.put('/theme', auth.authRequired, upload.single('bg'), (req, res) => {
  const b = req.body || {};
  if (typeof b.preset === 'string' && THEME_PRESETS.includes(b.preset)) {
    setSetting('theme_preset', b.preset);
  }
  const clearOld = () => {
    for (const key of ['theme_bg', 'theme_bg_video']) {
      const old = getSetting(key, '');
      if (old) { try { fs.unlinkSync(path.join(THEME_DIR, old)); } catch { /* ignore */ } }
      setSetting(key, '');
    }
  };
  if (b.clear_bg === '1') {
    clearOld();
  } else if (req.file) {
    const isVideo = /^video\//.test(req.file.mimetype) || /\.(mp4|webm)$/i.test(req.file.originalname);
    if (!isPng(req.file.buffer) && !/\.jpe?g$|\.png$|\.webp$/i.test(req.file.originalname) && !isVideo) {
      return res.status(400).json({ error: '背景支持 PNG / JPG / WebP 图片或 MP4 / WebM 视频' });
    }
    fs.mkdirSync(THEME_DIR, { recursive: true });
    clearOld();
    const ext = isVideo
      ? (/\.webm$/i.test(req.file.originalname) ? '.webm' : '.mp4')
      : (isPng(req.file.buffer) ? '.png' : (req.file.originalname.match(/\.(jpe?g|webp)$/i) || ['.jpg'])[0]);
    const name = isVideo ? `bg${ext}` : `bg${ext}`;
    fs.writeFileSync(path.join(THEME_DIR, name), req.file.buffer);
    setSetting(isVideo ? 'theme_bg_video' : 'theme_bg', name);
  }
  res.json({ ok: true, ...themeState() });
});

/* ---------------- 主动推送设置 ---------------- */

router.get('/proactive', auth.authRequired, (req, res) => {
  res.json({
    enabled: getSetting('proactive_enabled', '0') === '1',
    times: getSetting('proactive_times', '21:30'),
    random: getSetting('proactive_random', '0') === '1',
  });
});

router.put('/proactive', auth.authRequired, (req, res) => {
  const b = req.body || {};
  if (typeof b.enabled === 'boolean') setSetting('proactive_enabled', b.enabled ? '1' : '0');
  if (typeof b.random === 'boolean') setSetting('proactive_random', b.random ? '1' : '0');
  if (typeof b.times === 'string') {
    const times = b.times.split(',').map((s) => s.trim()).filter((s) => /^\d{1,2}:\d{2}$/.test(s)).slice(0, 5);
    setSetting('proactive_times', times.join(','));
  }
  res.json({ ok: true });
});

/* ---------------- 认证 ---------------- */

router.get('/auth/status', (req, res) => {
  res.json({ configured: auth.isConfigured() });
});

router.post('/auth/setup', (req, res) => {
  const password = String((req.body && req.body.password) || '');
  if (password.length < 4) return res.status(400).json({ error: '密码至少 4 位' });
  try {
    auth.setupPassword(password);
  } catch (e) {
    return res.status(400).json({ error: e.message });
  }
  auth.issueToken(res);
  res.json({ ok: true });
});

router.post('/login', (req, res) => {
  const ip = auth.clientIp(req);
  if (auth.isLocked(ip)) return res.status(429).json({ error: '尝试次数过多，请 1 分钟后再试' });
  const password = String((req.body && req.body.password) || '');
  if (!auth.verifyPassword(password)) {
    auth.registerFailure(ip);
    return res.status(401).json({ error: '密码不正确' });
  }
  auth.clearFailures(ip);
  auth.issueToken(res);
  res.json({ ok: true });
});

router.post('/logout', auth.authRequired, (req, res) => {
  auth.logout(req, res);
  res.json({ ok: true });
});

/* ---------------- 设置 ---------------- */

router.get('/settings', auth.authRequired, (req, res) => {
  const apiKey = getSetting('api_key', '');
  res.json({
    api_base: getSetting('api_base', ''),
    model: getSetting('model', ''),
    temperature: Number(getSetting('temperature', '0.8')),
    context_messages: Number(getSetting('context_messages', '40')),
    persona_name: getSetting('persona_name', 'User'),
    persona_description: getSetting('persona_description', ''),
    memory_interval: Number(getSetting('memory_interval', '20')),
    api_key_preview: apiKey ? `****${apiKey.slice(-4)}` : '',
  });
});

router.put('/settings', auth.authRequired, (req, res) => {
  const b = req.body || {};
  const strFields = ['api_base', 'model', 'persona_name', 'persona_description'];
  for (const f of strFields) {
    if (typeof b[f] === 'string') setSetting(f, b[f].trim());
  }
  if (b.temperature !== undefined) {
    const t = Number(b.temperature);
    if (Number.isFinite(t) && t >= 0 && t <= 2) setSetting('temperature', String(t));
  }
  if (b.context_messages !== undefined) {
    const n = Number(b.context_messages);
    if (Number.isFinite(n) && n >= 4 && n <= 500) setSetting('context_messages', String(Math.round(n)));
  }
  if (b.clear_api_key) setSetting('api_key', '');
  else if (typeof b.api_key === 'string' && b.api_key.trim()) setSetting('api_key', b.api_key.trim());
  if (b.memory_interval !== undefined) {
    const n = Number(b.memory_interval);
    if (Number.isFinite(n) && n >= 0 && n <= 200) setSetting('memory_interval', String(Math.round(n)));
  }
  res.json({ ok: true });
});

/* ---------------- 角色卡 ---------------- */

function getSettingsForLlm() {
  return {
    api_base: getSetting('api_base', ''),
    api_key: getSetting('api_key', ''),
    model: getSetting('model', ''),
    temperature: Number(getSetting('temperature', '0.8')),
    context_messages: Number(getSetting('context_messages', '40')),
    persona_name: getSetting('persona_name', 'User'),
    persona_description: getSetting('persona_description', ''),
  };
}

router.get('/characters', auth.authRequired, (req, res) => {
  const rows = db.prepare('SELECT * FROM characters ORDER BY id DESC').all();
  res.json(rows.map((r) => {
    const card = JSON.parse(r.card_json);
    return {
      id: r.id,
      name: r.name,
      has_avatar: !!r.avatar,
      tags: card.tags || [],
      creator: card.creator || '',
      spec: card.spec,
      has_greeting: !!(card.first_mes || (card.alternate_greetings || []).length),
      created_at: r.created_at,
    };
  }));
});

router.get('/characters/:id/avatar', auth.authRequired, (req, res) => {
  const row = db.prepare('SELECT avatar FROM characters WHERE id = ?').get(req.params.id);
  if (!row || !row.avatar) return res.status(404).end();
  res.setHeader('Cache-Control', 'private, max-age=86400');
  res.sendFile(row.avatar);
});

router.post('/characters/import', auth.authRequired, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: '没有收到文件' });
  const buffer = req.file.buffer;
  let card;
  try {
    card = isPng(buffer) ? parseCardFromPng(buffer) : parseCardFromJson(buffer.toString('utf8'));
  } catch (e) {
    return res.status(400).json({ error: e.message });
  }
  const now = Date.now();
  const info = db.prepare('INSERT INTO characters(name, avatar, card_json, created_at) VALUES(?,?,?,?)')
    .run(card.name, null, JSON.stringify(card), now);
  const id = Number(info.lastInsertRowid);
  if (isPng(buffer)) {
    const avatarPath = path.join(AVATAR_DIR, `${id}.png`);
    fs.writeFileSync(avatarPath, buffer);
    db.prepare('UPDATE characters SET avatar = ? WHERE id = ?').run(avatarPath, id);
  }
  res.json({ ok: true, id, name: card.name, spec: card.spec });
});

router.delete('/characters/:id', auth.authRequired, (req, res) => {
  const row = db.prepare('SELECT avatar FROM characters WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: '角色不存在' });
  db.prepare('DELETE FROM characters WHERE id = ?').run(req.params.id);
  if (row.avatar) { try { fs.unlinkSync(row.avatar); } catch { /* ignore */ } }
  res.json({ ok: true });
});

/* ---------------- 会话 ---------------- */

function getSession(id) {
  return db.prepare('SELECT * FROM sessions WHERE id = ?').get(id);
}

function touchSession(id) {
  db.prepare('UPDATE sessions SET updated_at = ? WHERE id = ?').run(Date.now(), id);
}

function insertGreeting(sessionId, card) {
  const greetings = [card.first_mes, ...(card.alternate_greetings || [])].filter((x) => x && x.trim());
  if (!greetings.length) return;
  const now = Date.now();
  db.prepare(`INSERT INTO messages(session_id, role, name, swipes, selected, is_greeting, created_at, updated_at)
              VALUES(?, 'assistant', ?, ?, 0, 1, ?, ?)`)
    .run(sessionId, card.nickname || card.name, JSON.stringify(greetings), now, now);
}

function sessionSummary(row) {
  const char = db.prepare('SELECT id, name, avatar FROM characters WHERE id = ?').get(row.character_id);
  const last = db.prepare('SELECT * FROM messages WHERE session_id = ? ORDER BY id DESC LIMIT 1').get(row.id);
  const lastMsg = rowToMessage(last);
  return {
    id: row.id,
    title: row.title,
    character_id: row.character_id,
    character_name: char ? char.name : '(角色已删除)',
    has_avatar: !!(char && char.avatar),
    updated_at: row.updated_at,
    last_message: lastMsg ? (lastMsg.content || '').slice(0, 80) : '',
  };
}

router.get('/sessions', auth.authRequired, (req, res) => {
  const rows = db.prepare('SELECT * FROM sessions ORDER BY updated_at DESC').all();
  res.json(rows.map(sessionSummary));
});

router.post('/sessions', auth.authRequired, (req, res) => {
  const characterId = Number(req.body && req.body.character_id);
  const char = db.prepare('SELECT * FROM characters WHERE id = ?').get(characterId);
  if (!char) return res.status(404).json({ error: '角色不存在' });
  const now = Date.now();
  const info = db.prepare('INSERT INTO sessions(character_id, title, created_at, updated_at) VALUES(?,?,?,?)')
    .run(characterId, char.name, now, now);
  const card = JSON.parse(char.card_json);
  insertGreeting(Number(info.lastInsertRowid), card);
  const row = getSession(Number(info.lastInsertRowid));
  res.json(sessionSummary(row));
});

router.patch('/sessions/:id', auth.authRequired, (req, res) => {
  const row = getSession(req.params.id);
  if (!row) return res.status(404).json({ error: '会话不存在' });
  if (typeof (req.body || {}).title === 'string' && req.body.title.trim()) {
    db.prepare('UPDATE sessions SET title = ? WHERE id = ?').run(req.body.title.trim().slice(0, 60), row.id);
  }
  res.json(sessionSummary(getSession(row.id)));
});

router.delete('/sessions/:id', auth.authRequired, (req, res) => {
  if (!getSession(req.params.id)) return res.status(404).json({ error: '会话不存在' });
  db.prepare('DELETE FROM sessions WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

router.delete('/sessions/:id/messages', auth.authRequired, (req, res) => {
  const row = getSession(req.params.id);
  if (!row) return res.status(404).json({ error: '会话不存在' });
  db.prepare('DELETE FROM messages WHERE session_id = ?').run(row.id);
  const char = db.prepare('SELECT * FROM characters WHERE id = ?').get(row.character_id);
  if (char) insertGreeting(row.id, JSON.parse(char.card_json));
  touchSession(row.id);
  res.json({ ok: true });
});

// 返回给客户端前统一做宏替换（{{user}}/{{char}}），存储层保留原文
router.get('/sessions/:id/messages', auth.authRequired, (req, res) => {
  const row = getSession(req.params.id);
  if (!row) return res.status(404).json({ error: '会话不存在' });
  const char = db.prepare('SELECT * FROM characters WHERE id = ?').get(row.character_id);
  const card = char ? JSON.parse(char.card_json) : null;
  const ctx = { char: card ? (card.nickname || card.name) : '', user: getSetting('persona_name', 'User') };
  const rows = db.prepare('SELECT * FROM messages WHERE session_id = ? ORDER BY id ASC').all(row.id);
  res.json(rows.map((r) => {
    const m = rowToMessage(r);
    m.content = substituteMacros(m.content, ctx);
    m.swipes = m.swipes.map((sw) => substituteMacros(sw, ctx));
    return m;
  }));
});

/* ---------------- 记忆池 ---------------- */

function enabledMemories(characterId) {
  return db.prepare('SELECT * FROM memories WHERE character_id = ? AND enabled = 1 ORDER BY id ASC').all(characterId);
}

async function callLlmText(settings, messages, timeoutMs = 90000) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), timeoutMs);
  let acc = '';
  try {
    for await (const delta of streamCompletion(settings, messages, ac.signal)) acc += delta;
  } finally {
    clearTimeout(timer);
  }
  return acc.trim();
}

function normalizeMemoryLine(line) {
  return line.replace(/^[-*•·\d.、\s]+/, '').replace(/\s+/g, ' ').trim();
}

// 让模型从会话历史里提炼新记忆，写入记忆池（去重），返回新增条目
async function summarizeSessionMemories(sessionId) {
  const session = getSession(sessionId);
  if (!session) throw new Error('会话不存在');
  const char = db.prepare('SELECT * FROM characters WHERE id = ?').get(session.character_id);
  if (!char) throw new Error('角色不存在');
  const card = JSON.parse(char.card_json);
  const settings = getSettingsForLlm();
  const charName = card.nickname || card.name;
  const userName = settings.persona_name || 'User';

  const existing = enabledMemories(char.id).map((m) => `- ${m.content}`);
  const history = historyForPrompt(sessionId, null).slice(-60);
  const transcript = history
    .map((m) => `${m.role === 'user' ? userName : charName}：${m.content}`)
    .join('\n');

  const messages = [
    {
      role: 'system',
      content: '你是记忆管理器，负责维护角色对用户的长期记忆。从对话中提取值得长期记住的新信息：用户的称呼、喜好、习惯、重要经历、两人的约定与关系进展。要求：每条一行，用第三人称简洁陈述（例如：用户喜欢在深夜听雨声）；只输出新信息，跳过与已有记忆重复或相似的内容；每次最多提取 5 条；如果没有值得记住的内容，只输出两个字：无。',
    },
    { role: 'user', content: `【已有记忆】\n${existing.length ? existing.join('\n') : '（暂无）'}\n\n【对话记录】\n${transcript}\n\n请输出新增的记忆条目。` },
  ];
  const raw = await callLlmText(settings, messages);
  if (!raw || /^无/.test(raw)) return [];

  const existingSet = new Set(existing.map((e) => e.slice(2)));
  const added = [];
  for (let line of raw.split(/\r?\n/)) {
    const norm = normalizeMemoryLine(line);
    if (norm.length < 4 || norm.length > 200) continue;
    if (norm === '无') continue;
    if (existingSet.has(norm)) continue;
    existingSet.add(norm);
    added.push(norm);
    if (added.length >= 5) break;
  }
  const now = Date.now();
  const insert = db.prepare('INSERT INTO memories(character_id, content, source, enabled, created_at, updated_at) VALUES(?,?,?,1,?,?)');
  for (const content of added) insert.run(char.id, content, 'auto', now, now);
  return added;
}

router.get('/characters/:id/memories', auth.authRequired, (req, res) => {
  const char = db.prepare('SELECT id FROM characters WHERE id = ?').get(req.params.id);
  if (!char) return res.status(404).json({ error: '角色不存在' });
  const rows = db.prepare('SELECT * FROM memories WHERE character_id = ? ORDER BY id DESC').all(char.id);
  res.json(rows.map((r) => ({
    id: r.id, content: r.content, source: r.source, enabled: !!r.enabled, created_at: r.created_at,
  })));
});

router.post('/characters/:id/memories', auth.authRequired, (req, res) => {
  const char = db.prepare('SELECT id FROM characters WHERE id = ?').get(req.params.id);
  if (!char) return res.status(404).json({ error: '角色不存在' });
  const content = String((req.body || {}).content || '').trim();
  if (content.length < 2 || content.length > 500) return res.status(400).json({ error: '记忆内容长度需在 2-500 字之间' });
  const now = Date.now();
  const info = db.prepare('INSERT INTO memories(character_id, content, source, enabled, created_at, updated_at) VALUES(?,?,?,1,?,?)')
    .run(char.id, content, 'manual', now, now);
  res.json({ ok: true, id: Number(info.lastInsertRowid), content, source: 'manual', enabled: true, created_at: now });
});

router.patch('/memories/:id', auth.authRequired, (req, res) => {
  const row = db.prepare('SELECT * FROM memories WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: '记忆不存在' });
  const b = req.body || {};
  if (typeof b.content === 'string') {
    const content = b.content.trim();
    if (content.length < 2 || content.length > 500) return res.status(400).json({ error: '记忆内容长度需在 2-500 字之间' });
    db.prepare('UPDATE memories SET content = ?, updated_at = ? WHERE id = ?').run(content, Date.now(), row.id);
  }
  if (typeof b.enabled === 'boolean') {
    db.prepare('UPDATE memories SET enabled = ?, updated_at = ? WHERE id = ?').run(b.enabled ? 1 : 0, Date.now(), row.id);
  }
  const updated = db.prepare('SELECT * FROM memories WHERE id = ?').get(row.id);
  res.json({ ok: true, id: updated.id, content: updated.content, source: updated.source, enabled: !!updated.enabled, created_at: updated.created_at });
});

router.delete('/memories/:id', auth.authRequired, (req, res) => {
  const row = db.prepare('SELECT id FROM memories WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: '记忆不存在' });
  db.prepare('DELETE FROM memories WHERE id = ?').run(row.id);
  res.json({ ok: true });
});

// 手动从该角色最近一个会话总结记忆
router.post('/characters/:id/remember', auth.authRequired, async (req, res) => {
  try {
    const session = db.prepare('SELECT * FROM sessions WHERE character_id = ? ORDER BY updated_at DESC LIMIT 1').get(req.params.id);
    if (!session) return res.status(400).json({ error: '这个角色还没有聊天记录，先去聊聊吧' });
    const added = await summarizeSessionMemories(session.id);
    res.json({ ok: true, added });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/* ---------------- 悄悄话（Today's Whisper） ---------------- */

router.post('/characters/:id/whisper', auth.authRequired, async (req, res) => {
  try {
    const char = db.prepare('SELECT * FROM characters WHERE id = ?').get(req.params.id);
    if (!char) return res.status(404).json({ error: '角色不存在' });
    const card = JSON.parse(char.card_json);
    const settings = getSettingsForLlm();
    const charName = card.nickname || card.name;
    const userName = settings.persona_name || 'User';
    const memories = enabledMemories(char.id).map((m) => `- ${m.content}`).join('\n') || '（暂无）';
    const hour = new Date().getHours();

    const text = await callLlmText(settings, [
      {
        role: 'system',
        content: `你是「${charName}」，正给「${userName}」的手机发送一条今日悄悄话。结合你的人设、现在的时段（${hour}点）和你们的记忆，写一句 20~40 字的话：可以是问候、撒娇、吐槽或小事分享，符合角色语气，不要解释、不要署名。\n你的人设：${(card.description + ' ' + card.personality).slice(0, 500)}\n你们的记忆：\n${memories}`,
      },
      { role: 'user', content: '请发送今日悄悄话' },
    ], 45000);
    if (!text) throw new Error('模型没有返回内容');
    db.prepare('INSERT INTO whispers(character_id, text, created_at) VALUES(?,?,?) ON CONFLICT(character_id) DO UPDATE SET text = excluded.text, created_at = excluded.created_at')
      .run(char.id, text, Date.now());
    res.json({ ok: true, text });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/* ---------------- 首页仪表盘 ---------------- */

router.get('/home', auth.authRequired, (req, res) => {
  const chars = db.prepare('SELECT * FROM characters ORDER BY id DESC').all();
  if (!chars.length) return res.json({ character: null, characters: [] });

  let char = null;
  const wanted = Number(req.query.character_id);
  if (Number.isInteger(wanted)) char = chars.find((c) => c.id === wanted) || null;
  if (!char) {
    const lastSession = db.prepare('SELECT character_id FROM sessions ORDER BY updated_at DESC LIMIT 1').get();
    char = (lastSession && chars.find((c) => c.id === lastSession.character_id)) || chars[0];
  }
  const card = JSON.parse(char.card_json);

  const first = db.prepare('SELECT MIN(created_at) AS t FROM sessions WHERE character_id = ?').get(char.id);
  const firstAt = first && first.t ? first.t : null;
  const day = firstAt ? Math.floor((Date.now() - firstAt) / 86400000) + 1 : 0;
  const messageCount = db.prepare(`SELECT COUNT(*) AS n FROM messages m JOIN sessions s ON m.session_id = s.id WHERE s.character_id = ?`).get(char.id).n;
  const memoryCount = db.prepare('SELECT COUNT(*) AS n FROM memories WHERE character_id = ? AND enabled = 1').get(char.id).n;
  const whisper = db.prepare('SELECT text, created_at FROM whispers WHERE character_id = ?').get(char.id);
  const lastSession = db.prepare('SELECT id FROM sessions WHERE character_id = ? ORDER BY updated_at DESC LIMIT 1').get(char.id);

  res.json({
    character: {
      id: char.id, name: char.name, nickname: card.nickname || '',
      has_avatar: !!char.avatar, tags: card.tags || [],
    },
    characters: chars.map((c) => {
      const cj = JSON.parse(c.card_json);
      return { id: c.id, name: c.name, has_avatar: !!c.avatar, nickname: cj.nickname || '' };
    }),
    day, first_chat_at: firstAt, message_count: messageCount, memory_count: memoryCount,
    session_id: lastSession ? lastSession.id : null,
    whisper: whisper || null,
  });
});

/* ---------------- 生成（SSE） ---------------- */

function sseStart(res) {
  res.status(200);
  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();
}

function sseEvent(res, event, data) {
  res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
}

function historyForPrompt(sessionId, excludeMessageId) {
  const rows = db.prepare('SELECT * FROM messages WHERE session_id = ? ORDER BY id ASC').all(sessionId);
  return rows
    .filter((r) => r.id !== excludeMessageId)
    .map((r) => {
      const swipes = JSON.parse(r.swipes || '[]');
      return { role: r.role, content: swipes[Math.min(r.selected, swipes.length - 1)] ?? '' };
    })
    .filter((m) => m.content && m.content.trim());
}

async function runGeneration(res, sessionId, messageId, history) {
  const session = getSession(sessionId);
  const char = db.prepare('SELECT * FROM characters WHERE id = ?').get(session.character_id);
  const card = JSON.parse(char.card_json);
  const settings = getSettingsForLlm();
  const memories = db.prepare('SELECT content FROM memories WHERE character_id = ? AND enabled = 1 ORDER BY id ASC').all(char.id);
  const promptMessages = buildMessages({ card, settings, history, memories });

  sseStart(res);
  sseEvent(res, 'start', { messageId });

  let acc = '';
  const ac = new AbortController();
  let clientGone = false;
  res.on('close', () => { clientGone = true; ac.abort(); });

  const persist = () => {
    if (acc.trim()) {
      const row = db.prepare('SELECT swipes FROM messages WHERE id = ?').get(messageId);
      const swipes = JSON.parse((row && row.swipes) || '[]');
      swipes.push(acc.trim());
      db.prepare('UPDATE messages SET swipes = ?, selected = ?, updated_at = ? WHERE id = ?')
        .run(JSON.stringify(swipes), swipes.length - 1, Date.now(), messageId);
      touchSession(sessionId);
      return { swipes, selected: swipes.length - 1 };
    }
    // 一点内容都没有：新消息直接删掉，避免留下空气泡
    const row = db.prepare('SELECT swipes FROM messages WHERE id = ?').get(messageId);
    const swipes = JSON.parse((row && row.swipes) || '[]');
    if (!swipes.length) db.prepare('DELETE FROM messages WHERE id = ?').run(messageId);
    return null;
  };

  try {
    for await (const delta of streamCompletion(settings, promptMessages, ac.signal)) {
      acc += delta;
      if (!clientGone) sseEvent(res, 'delta', { text: acc });
    }
    const saved = persist();
    if (!clientGone) {
      if (saved) sseEvent(res, 'done', { messageId, content: acc.trim(), swipes: saved.swipes, selected: saved.selected });
      else sseEvent(res, 'error', { message: '模型没有返回内容' });
      res.end();
    }
  } catch (e) {
    const saved = persist();
    const msg = e.name === 'AbortError' ? '已停止' : e.message;
    if (!clientGone) {
      if (saved) sseEvent(res, 'done', { messageId, content: acc.trim(), swipes: saved.swipes, selected: saved.selected, aborted: e.name === 'AbortError' });
      else sseEvent(res, 'error', { message: msg });
      res.end();
    }
  } finally {
    generating.delete(sessionId);
  }
}

router.post('/sessions/:id/chat', auth.authRequired, async (req, res) => {
  const session = getSession(req.params.id);
  if (!session) return res.status(404).json({ error: '会话不存在' });
  if (generating.has(session.id)) return res.status(409).json({ error: '该会话正在回复中，请稍候' });
  const content = String((req.body && req.body.content) || '').trim();
  if (!content) return res.status(400).json({ error: '消息内容不能为空' });

  generating.add(session.id);
  try {
    const now = Date.now();
    db.prepare(`INSERT INTO messages(session_id, role, name, swipes, selected, is_greeting, created_at, updated_at)
                VALUES(?, 'user', ?, ?, 0, 0, ?, ?)`)
      .run(session.id, getSetting('persona_name', 'User'), JSON.stringify([content]), now, now);
    const assistantInfo = db.prepare(`INSERT INTO messages(session_id, role, name, swipes, selected, is_greeting, created_at, updated_at)
                VALUES(?, 'assistant', ?, '[]', 0, 0, ?, ?)`)
      .run(session.id, '', now, now);
    const history = historyForPrompt(session.id, Number(assistantInfo.lastInsertRowid));
    await runGeneration(res, session.id, Number(assistantInfo.lastInsertRowid), history);

    // 每聊 N 条自动沉淀记忆（后台执行，不阻塞响应）
    const interval = Number(getSetting('memory_interval', '20'));
    if (interval > 0) {
      const userCount = db.prepare(`SELECT COUNT(*) AS n FROM messages WHERE session_id = ? AND role = 'user'`).get(session.id).n;
      if (userCount > 0 && userCount % interval === 0) {
        summarizeSessionMemories(session.id).catch((e) => console.error('自动记忆总结失败：', e.message));
      }
    }
  } catch (e) {
    generating.delete(session.id);
    if (!res.headersSent) res.status(500).json({ error: e.message });
    else res.end();
  }
});

router.post('/sessions/:id/regenerate', auth.authRequired, async (req, res) => {
  const session = getSession(req.params.id);
  if (!session) return res.status(404).json({ error: '会话不存在' });
  if (generating.has(session.id)) return res.status(409).json({ error: '该会话正在回复中，请稍候' });

  const last = db.prepare('SELECT * FROM messages WHERE session_id = ? ORDER BY id DESC LIMIT 1').get(session.id);
  if (!last) return res.status(400).json({ error: '会话中没有可重试的消息' });
  if (last.is_greeting) return res.status(400).json({ error: '开场白不能重新生成，可以用左右箭头切换' });
  if (last.role !== 'assistant') return res.status(400).json({ error: '最后一条不是角色回复，无法重试' });

  generating.add(session.id);
  try {
    const history = historyForPrompt(session.id, last.id);
    await runGeneration(res, session.id, last.id, history);
  } catch (e) {
    generating.delete(session.id);
    if (!res.headersSent) res.status(500).json({ error: e.message });
    else res.end();
  }
});

/* ---------------- 消息操作 ---------------- */

router.post('/messages/:id/swipe', auth.authRequired, (req, res) => {
  const row = db.prepare('SELECT * FROM messages WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: '消息不存在' });
  const swipes = JSON.parse(row.swipes || '[]');
  if (swipes.length <= 1) return res.status(400).json({ error: '这条消息没有其他备选' });

  const b = req.body || {};
  let next = row.selected;
  if (Number.isInteger(b.index) && b.index >= 0 && b.index < swipes.length) next = b.index;
  else if (b.direction === 'prev') next = (row.selected - 1 + swipes.length) % swipes.length;
  else next = (row.selected + 1) % swipes.length;

  db.prepare('UPDATE messages SET selected = ?, updated_at = ? WHERE id = ?').run(next, Date.now(), row.id);
  touchSession(row.session_id);
  res.json({ ok: true, selected: next, swipes });
});

router.patch('/messages/:id', auth.authRequired, (req, res) => {
  const row = db.prepare('SELECT * FROM messages WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: '消息不存在' });
  const content = String((req.body || {}).content || '').trim();
  if (!content) return res.status(400).json({ error: '内容不能为空' });
  const swipes = JSON.parse(row.swipes || '[]');
  if (!swipes.length) swipes.push(content);
  else swipes[Math.min(row.selected, swipes.length - 1)] = content;
  db.prepare('UPDATE messages SET swipes = ?, updated_at = ? WHERE id = ?').run(JSON.stringify(swipes), Date.now(), row.id);
  touchSession(row.session_id);
  res.json({ ok: true });
});

router.delete('/messages/:id', auth.authRequired, (req, res) => {
  const row = db.prepare('SELECT * FROM messages WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: '消息不存在' });
  db.prepare('DELETE FROM messages WHERE id = ?').run(row.id);
  touchSession(row.session_id);
  res.json({ ok: true });
});

module.exports = router;
