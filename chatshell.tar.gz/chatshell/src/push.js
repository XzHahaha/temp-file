// 主动消息：定时生成角色发起的一句话，插入会话并通过 Web Push 推送
const webpush = require('web-push');
const { db, getSetting, setSetting } = require('./db');
const { streamCompletion } = require('./llm');

function vapidKeys() {
  let pub = getSetting('vapid_public_key');
  let priv = getSetting('vapid_private_key');
  if (!pub || !priv) {
    const keys = webpush.generateVAPIDKeys();
    setSetting('vapid_public_key', keys.publicKey);
    setSetting('vapid_private_key', keys.privateKey);
    pub = keys.publicKey;
    priv = keys.privateKey;
  }
  return { publicKey: pub, privateKey: priv };
}

let vapidReady = false;
function ensureVapid() {
  if (!vapidReady) {
    webpush.setVapidDetails('mailto:chatshell@localhost', vapidKeys().publicKey, vapidKeys().privateKey);
    vapidReady = true;
  }
}

function proSettings() {
  return {
    enabled: getSetting('proactive_enabled', '0') === '1',
    count: Math.max(1, Math.min(50, Math.round(Number(getSetting('proactive_count', '3')) || 3))),
  };
}

function sendToCharacterSubs(characterId, title, body) {
  const subs = db.prepare('SELECT * FROM push_subs WHERE character_id = ? OR character_id IS NULL').all(characterId);
  const payload = JSON.stringify({ title, body, url: '/?from=push' });
  for (const s of subs) {
    webpush.sendNotification(
      { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
      payload,
    ).catch((e) => {
      if (e.statusCode === 404 || e.statusCode === 410) {
        db.prepare('DELETE FROM push_subs WHERE endpoint = ?').run(s.endpoint); // 订阅已失效
      }
    });
  }
}

// 生成一句角色主动发起的话，插入最近会话并推送
async function fireProactive(characterId) {
  const char = db.prepare('SELECT * FROM characters WHERE id = ?').get(characterId);
  if (!char) return;
  const card = JSON.parse(char.card_json);
  const charName = card.nickname || card.name;
  const session = db.prepare('SELECT * FROM sessions WHERE character_id = ? ORDER BY updated_at DESC LIMIT 1').get(characterId);
  if (!session) return; // 还没聊过天，没有可挂靠的会话

  const userName = getSetting('persona_name', 'User');
  const memories = db.prepare('SELECT content FROM memories WHERE character_id = ? AND enabled = 1 ORDER BY id DESC LIMIT 10').all(characterId)
    .map((m) => `- ${m.content}`).join('\n') || '（暂无）';
  const recent = db.prepare('SELECT * FROM messages WHERE session_id = ? ORDER BY id DESC LIMIT 6').all(session.id)
    .reverse().map((m) => {
      const swipes = JSON.parse(m.swipes || '[]');
      const content = swipes[Math.min(m.selected, Math.max(swipes.length - 1, 0))] ?? '';
      return `${m.role === 'user' ? userName : charName}：${content.slice(0, 100)}`;
    }).join('\n');
  const hour = new Date().getHours();
  const cfg = {
    api_base: getSetting('api_base', ''),
    api_key: getSetting('api_key', ''),
    model: getSetting('model', ''),
    temperature: Number(getSetting('temperature', '0.8')),
  };

  let text = '';
  try {
    for await (const delta of streamCompletion(cfg, [
      {
        role: 'system',
        content: `你是「${charName}」，现在（${hour}点）想主动给「${userName}」发一条消息。结合你的人设、时段和你们的对话氛围，写一句 20~50 字的主动搭话：可以是关心、分享、撒娇或吐槽，要符合角色语气，像随手发来的微信，不要解释、不要署名。\n你的人设：${(card.description + ' ' + card.personality).slice(0, 400)}\n你们最近的对话：\n${recent}\n你记得的事：\n${memories}`,
      },
      { role: 'user', content: '请发出这条主动消息' },
    ])) text += delta;
  } catch (e) {
    console.error('主动消息生成失败：', e.message);
    return;
  }
  text = text.trim();
  if (!text) return;

  const now = Date.now();
  db.prepare(`INSERT INTO messages(session_id, role, name, swipes, selected, is_greeting, created_at, updated_at)
              VALUES(?, 'assistant', ?, ?, 0, 0, ?, ?)`)
    .run(session.id, charName, JSON.stringify([text]), now, now);
  db.prepare('UPDATE sessions SET updated_at = ? WHERE id = ?').run(now, session.id);
  sendToCharacterSubs(characterId, `${charName} 发来了一条消息`, text.slice(0, 120));
  console.log(`[主动消息] ${charName} -> ${userName}：${text.slice(0, 50)}…`);
}

function hhmm() {
  const d = new Date();
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

async function tick() {
  try {
    const cfg = proSettings();
    if (!cfg.enabled) return;
    const now = new Date();
    const today = now.toDateString();

    // 当日已发条数
    let daily;
    try { daily = JSON.parse(getSetting('proactive_daily', '{}')); } catch { daily = {}; }
    if (daily.date !== today) { daily = { date: today, count: 0 }; }
    if (daily.count >= cfg.count) return;

    // 剩余额度摊到今天剩余的每分钟上（全天不限时段）
    const elapsed = now.getHours() * 60 + now.getMinutes();
    const remainingMin = Math.max(1, 1440 - elapsed);
    const p = Math.min(0.5, ((cfg.count - daily.count) / remainingMin) * 1.2);
    if (Math.random() >= p) return;

    daily.count += 1;
    setSetting('proactive_daily', JSON.stringify(daily));
    for (const c of db.prepare('SELECT id FROM characters').all()) await fireProactive(c.id);
  } catch (e) {
    console.error('主动消息调度异常：', e.message);
  }
}

function startScheduler() {
  ensureVapid();
  setInterval(tick, 60 * 1000);
  console.log('主动消息调度器已启动（每分钟检查一次）');
}

module.exports = { vapidKeys, startScheduler, fireProactive, sendToCharacterSubs };
