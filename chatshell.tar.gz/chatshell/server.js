const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const https = require('node:https');
const express = require('express');
const routes = require('./src/routes');
const push = require('./src/push');

const [major] = process.versions.node.split('.').map(Number);
if (major < 22) {
  console.error(`需要 Node.js 22.12 以上版本（当前 ${process.versions.node}），请先升级 Node。`);
  process.exit(1);
}

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '2mb' }));
app.use('/api', routes);

const PUBLIC_DIR = path.join(__dirname, 'public');
app.use(express.static(PUBLIC_DIR, { etag: true, maxAge: 0 }));

app.use((req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: '接口不存在' });
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

const PORT = Number(process.env.PORT) || 3000;

// 设置 SSL_CERT / SSL_KEY 环境变量即启用 HTTPS（Web Push 和 PWA 安装需要）
const { SSL_CERT, SSL_KEY } = process.env;
const httpsEnabled = SSL_CERT && SSL_KEY && fs.existsSync(SSL_CERT) && fs.existsSync(SSL_KEY);
const server = httpsEnabled
  ? https.createServer({ cert: fs.readFileSync(SSL_CERT), key: fs.readFileSync(SSL_KEY) }, app)
  : app;

server.listen(PORT, () => {
  console.log(`聊天壳已启动：http${httpsEnabled ? 's' : ''}://localhost:${PORT}`);
  if (!httpsEnabled) console.log('提示：设置 SSL_CERT / SSL_KEY 环境变量可开启 HTTPS（手机通知和 App 安装需要）。');
  console.log('首次打开网页时会要求设置访问密码；模型 API 在网页「设置」里填写。');
  push.startScheduler();
});
