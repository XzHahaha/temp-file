/* 聊天壳前端 */

const S = {
  tab: 'home',
  configured: true,
  settings: null,
  characters: [],
  home: null,
  homeCharId: null,
  sessions: [],
  memCharId: null,
  memories: [],
  chat: null,           // { id, session, messages }
  generating: false,
  abort: null,
};

const $ = (id) => document.getElementById(id);

/* ---------------- 基础工具 ---------------- */

function esc(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

function md(s) {
  return esc(s)
    .replace(/\*\*\*([^*]+)\*\*\*/g, '<b><i>$1</i></b>')
    .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
    .replace(/\*([^*\n]+)\*/g, '<i>$1</i>')
    .replace(/`([^`\n]+)`/g, '<code>$1</code>')
    .replace(/\n/g, '<br>');
}

async function api(path, opts = {}) {
  const res = await fetch('/api' + path, {
    credentials: 'same-origin',
    headers: opts.body instanceof FormData ? undefined : { 'Content-Type': 'application/json' },
    ...opts,
  });
  if (res.status === 401 && !path.startsWith('/auth') && !path.startsWith('/login')) {
    showLogin();
    throw new Error('登录已过期，请重新登录');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `请求失败（${res.status}）`);
  return data;
}

let toastTimer = null;
function toast(msg) {
  const el = $('toast');
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 2600);
}

function openModal(html) {
  const root = $('modal-root');
  root.innerHTML = `<div class="modal">${html}</div>`;
  root.style.display = 'flex';
  const close = () => { root.style.display = 'none'; root.innerHTML = ''; };
  root.onclick = (e) => { if (e.target === root) close(); };
  return { root, close, modal: root.firstChild };
}

function confirmModal(title, text, { danger = false, confirmText = '确定' } = {}) {
  return new Promise((resolve) => {
    const { close, modal } = openModal(`
      <h3>${esc(title)}</h3><p class="sub">${esc(text)}</p>
      <div class="row"><button class="btn-ghost" data-no>取消</button>
      <button class="${danger ? 'btn-danger' : 'btn-solid'}" data-yes>${esc(confirmText)}</button></div>`);
    modal.querySelector('[data-no]').onclick = () => { close(); resolve(false); };
    modal.querySelector('[data-yes]').onclick = () => { close(); resolve(true); };
  });
}

function promptModal(title, { initial = '', textarea = true, placeholder = '' } = {}) {
  return new Promise((resolve) => {
    const { close, modal } = openModal(`
      <h3>${esc(title)}</h3>
      ${textarea ? `<textarea rows="5" placeholder="${esc(placeholder)}">${esc(initial)}</textarea>`
                 : `<input placeholder="${esc(placeholder)}" value="${esc(initial)}">`}
      <div class="row"><button class="btn-ghost" data-no>取消</button><button class="btn-solid" data-yes>保存</button></div>`);
    const input = modal.querySelector(textarea ? 'textarea' : 'input');
    input.focus();
    const yes = () => { const v = input.value.trim(); close(); resolve(v || null); };
    modal.querySelector('[data-no]').onclick = () => { close(); resolve(null); };
    modal.querySelector('[data-yes]').onclick = yes;
    input.onkeydown = (e) => { if (e.key === 'Enter' && !textarea && !e.isComposing) yes(); };
  });
}

function avatarInto(el, char, letter) {
  el.innerHTML = '';
  el.style.backgroundImage = '';
  const name = letter || (char ? (char.nickname || char.name) : '?');
  if (char && char.has_avatar) {
    const img = document.createElement('img');
    img.src = `/api/characters/${char.id}/avatar`;
    img.alt = name;
    el.appendChild(img);
  } else {
    el.textContent = (name || '?').trim().charAt(0).toUpperCase() || '?';
  }
}

function relTime(ts) {
  if (!ts) return '';
  const diff = Date.now() - ts;
  if (diff < 60000) return '刚刚';
  if (diff < 3600000) return `${Math.floor(diff / 60000)} 分钟前`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)} 小时前`;
  if (diff < 172800000) return '昨天';
  const d = new Date(ts);
  return `${d.getMonth() + 1}月${d.getDate()}日`;
}

/* ---------------- 启动与登录 ---------------- */

async function boot() {
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
  loadTheme(); // 主题对登录页也生效
  try {
    // 已有有效会话则直接进主界面，否则停在登录页
    await api('/settings');
    await initApp();
  } catch {
    try {
      const st = await api('/auth/status');
      S.configured = st.configured;
    } catch { /* 服务器不可达时也停在登录页 */ }
    showLogin();
  }
}

function showLogin() {
  $('app-view').classList.add('hidden');
  $('chat-view').classList.add('hidden');
  $('login-view').classList.remove('hidden');
  if (!S.configured) {
    $('login-title').textContent = '你好';
    $('login-sub').textContent = '第一次使用，先设置一个访问密码';
    $('btn-login').textContent = '保存密码并进入';
  }
  $('login-password').focus();
}

$('btn-login').onclick = async () => {
  const pw = $('login-password').value;
  if (!pw) return;
  try {
    await api(S.configured ? '/login' : '/auth/setup', { method: 'POST', body: JSON.stringify({ password: pw }) });
    await initApp();
  } catch (e) {
    $('login-err').textContent = e.message;
  }
};
$('login-password').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.isComposing) $('btn-login').click();
});

async function initApp() {
  $('login-err') && ($('login-err').textContent = '');
  $('login-view').classList.add('hidden');
  $('app-view').classList.remove('hidden');

  const d = new Date();
  const week = ['日', '一', '二', '三', '四', '五', '六'][d.getDay()];
  $('top-date').textContent = `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日 · 周${week}`;

  await Promise.all([loadSettings(), loadHome(), loadSessions(), loadCharacters()]);
  await initThemeUI();
  await loadProactive();

  // 从通知点进来：直接打开最近会话
  if (new URLSearchParams(location.search).get('from') === 'push' && S.sessions.length) {
    history.replaceState(null, '', '/');
    openChat(S.sessions[0].id);
  }
}

/* ---------------- Tab 切换 ---------------- */

document.querySelectorAll('.tab-btn').forEach((btn) => {
  btn.onclick = () => switchTab(btn.dataset.tab);
});
$('btn-me').onclick = () => switchTab('me');

function switchTab(tab) {
  S.tab = tab;
  document.querySelectorAll('.tab-btn').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
  ['home', 'chats', 'memory', 'me'].forEach((t) => $(`tab-${t}`).classList.toggle('hidden', t !== tab));
  if (tab === 'chats') loadSessions();
  if (tab === 'memory') loadMemories();
  if (tab === 'me') { loadSettings(); loadCharacters(); }
  if (tab === 'home') loadHome();
}

/* ---------------- 首页 ---------------- */

function greetingNow() {
  const h = new Date().getHours();
  if (h < 5) return ['Good night.', '夜深了，注意休息'];
  if (h < 11) return ['Good morning.', '早上好，新的一天'];
  if (h < 14) return ['Good noon.', '中午好'];
  if (h < 18) return ['Good afternoon.', '下午好'];
  if (h < 23) return ['Good evening.', '晚上好'];
  return ['Good night.', '晚安，好梦'];
}

async function loadHome(charId) {
  const id = charId || S.homeCharId;
  let home;
  try {
    home = await api('/home' + (id ? `?character_id=${id}` : ''));
  } catch (e) { toast(e.message); return; }
  S.home = home;
  if (home.character) S.homeCharId = home.character.id;

  const empty = !home.character;
  $('home-empty').classList.toggle('hidden', !empty);
  $('home-card').classList.toggle('hidden', empty);
  if (empty) return;

  const [gt, gs] = greetingNow();
  $('greet-title').textContent = gt;
  $('greet-sub').textContent = `${gs}，${home.character.nickname || home.character.name}在等你`;

  // 角色切换
  const chips = $('home-chips');
  chips.innerHTML = '';
  home.characters.forEach((c) => {
    const b = document.createElement('button');
    b.className = 'chip' + (c.id === home.character.id ? ' active' : '');
    const av = document.createElement('span');
    av.className = 'avatar small';
    avatarInto(av, c);
    b.appendChild(av);
    b.appendChild(document.createTextNode(c.nickname || c.name));
    b.onclick = () => loadHome(c.id);
    chips.appendChild(b);
  });

  avatarInto($('whisper-avatar'), home.character);
  const w = home.whisper;
  $('whisper-text').textContent = w ? w.text : '点一下右边的按钮，听听 TA 今天想对你说什么。';
  $('whisper-text').classList.toggle('pending', !w);
  $('whisper-date').textContent = w ? new Date(w.created_at).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '还没有悄悄话';

  const day = home.day;
  $('home-day').textContent = day;
  $('home-day-pill').classList.toggle('hidden', day > 0);
  if (day === 0) $('home-day-pill').textContent = '准备阶段';

  const p = (day % 30) / 30;
  $('ring-arc').style.strokeDashoffset = String(169.6 * (1 - p));
  $('ring-text').textContent = day === 0 ? '还没有开始'
    : `第 ${day} 天 · 满月纪念在第 ${Math.floor((day - 1) / 30) * 30 + 30} 天`;

  $('stat-memory').textContent = home.memory_count;
  $('stat-messages').textContent = home.message_count;
  $('btn-start-chat').textContent = home.session_id ? '继续和 TA 聊天' : '开始我们的第一天';
}

$('btn-start-chat').onclick = async () => {
  if (!S.home || !S.home.character) return;
  if (S.home.session_id) return openChat(S.home.session_id);
  try {
    const s = await api('/sessions', { method: 'POST', body: JSON.stringify({ character_id: S.home.character.id }) });
    await loadSessions();
    await loadHome();
    openChat(s.id);
  } catch (e) { toast(e.message); }
};

$('btn-import-first').onclick = () => $('file-input').click();

$('btn-whisper').onclick = async () => {
  if (!S.home || !S.home.character) return;
  const btn = $('btn-whisper');
  btn.disabled = true;
  $('whisper-text').textContent = 'TA 正在想说什么…';
  $('whisper-text').classList.add('pending');
  try {
    const r = await api(`/characters/${S.home.character.id}/whisper`, { method: 'POST' });
    $('whisper-text').textContent = r.text;
    $('whisper-text').classList.remove('pending');
    $('whisper-date').textContent = new Date().toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch (e) {
    toast(e.message);
    $('whisper-text').textContent = '（生成失败，稍后再试）';
  } finally {
    btn.disabled = false;
  }
};

/* ---------------- 会话列表 ---------------- */

async function loadSessions() {
  try {
    S.sessions = await api('/sessions');
  } catch (e) { toast(e.message); return; }
  const list = $('session-list');
  list.innerHTML = '';
  if (!S.sessions.length) {
    list.innerHTML = `<div class="list-empty">还没有对话。<br>点右上角 ＋，选一个角色开始聊天。</div>`;
    return;
  }
  S.sessions.forEach((s) => {
    const item = document.createElement('div');
    item.className = 'session-item';
    const av = document.createElement('span');
    av.className = 'avatar';
    avatarInto(av, s, s.character_name);
    const meta = document.createElement('div');
    meta.className = 'session-meta';
    meta.innerHTML = `<b>${esc(s.title || s.character_name)}</b><span>${esc(s.last_message || '…')}</span>`;
    const time = document.createElement('span');
    time.className = 'session-time';
    time.textContent = relTime(s.updated_at);
    item.append(av, meta, time);
    item.onclick = () => openChat(s.id);
    list.appendChild(item);
  });
}

$('btn-new-chat').onclick = async () => {
  let chars;
  try { chars = await api('/characters'); } catch (e) { toast(e.message); return; }
  if (!chars.length) {
    toast('还没有角色，先去「我的 → 导入角色卡」');
    switchTab('me');
    return;
  }
  const { close, modal } = openModal(`
    <h3>和谁聊聊？</h3><p class="sub">选择一个角色，开始新的对话</p>
    <div class="pick-grid">${chars.map((c, i) => `
      <div class="pick-item" data-i="${i}"><span class="avatar" data-av="${i}"></span><span>${esc(c.nickname || c.name)}</span></div>`).join('')}
    </div>`);
  modal.querySelectorAll('[data-av]').forEach((el) => avatarInto(el, chars[Number(el.dataset.av)]));
  modal.querySelectorAll('.pick-item').forEach((el) => {
    el.onclick = async () => {
      const c = chars[Number(el.dataset.i)];
      close();
      try {
        const s = await api('/sessions', { method: 'POST', body: JSON.stringify({ character_id: c.id }) });
        await loadSessions();
        openChat(s.id);
      } catch (e) { toast(e.message); }
    };
  });
};

/* ---------------- 聊天 ---------------- */

async function openChat(sessionId) {
  const session = S.sessions.find((s) => s.id === sessionId)
    || (S.sessions.length ? null : null);
  S.chat = { id: sessionId, session: session || null, messages: [] };
  const view = $('chat-view');
  view.classList.remove('hidden', 'chat-anim-out');
  view.classList.add('chat-anim-in');
  view.addEventListener('animationend', () => view.classList.remove('chat-anim-in'), { once: true });
  if (!session) await loadSessions();
  S.chat.session = S.sessions.find((s) => s.id === sessionId);
  renderChatHeader();
  await reloadMessages();
}

// iOS 式滑出关闭聊天页
function closeChatAnimated() {
  const view = $('chat-view');
  view.classList.remove('chat-anim-in');
  view.classList.add('chat-anim-out');
  view.addEventListener('animationend', () => {
    view.classList.remove('chat-anim-out');
    view.style.transform = '';
    view.classList.add('hidden');
    S.chat = null;
    loadSessions();
    loadHome();
  }, { once: true });
}

function renderChatHeader() {
  const s = S.chat && S.chat.session;
  if (!s) return;
  $('chat-title').textContent = s.title || s.character_name;
  avatarInto($('chat-avatar'), s, s.character_name);
  $('chat-status').textContent = '本地保存 · 上下文隔离';
}

$('btn-chat-back').onclick = closeChatAnimated;

// 左边缘右滑返回（iOS 手势）
(() => {
  const view = $('chat-view');
  let startX = null, startY = null, tracking = false, dx = 0;
  view.addEventListener('touchstart', (e) => {
    if (S.generating) return;
    const t = e.touches[0];
    if (t.clientX > 42) return; // 只认屏幕最左边缘
    startX = t.clientX; startY = t.clientY; tracking = false; dx = 0;
  }, { passive: true });
  view.addEventListener('touchmove', (e) => {
    if (startX == null) return;
    const t = e.touches[0];
    dx = t.clientX - startX;
    const dy = Math.abs(t.clientY - startY);
    if (!tracking) {
      // 横向意图明显才进入手势，避免和纵向滚动打架
      if (dx > 14 && dx > dy * 1.6) tracking = true;
      else if (dy > 12) { startX = null; return; }
    }
    if (tracking) {
      e.preventDefault();
      view.style.transition = 'none';
      view.style.transform = `translateX(${Math.max(dx, 0)}px)`;
    }
  }, { passive: false });
  view.addEventListener('touchend', () => {
    if (startX == null) return;
    if (tracking) {
      const w = view.offsetWidth;
      view.style.transition = 'transform .2s ease';
      if (dx > w * 0.32) {
        view.style.transform = `translateX(${w}px)`;
        view.addEventListener('transitionend', () => {
          view.style.transition = '';
          view.style.transform = '';
          closeChatAnimated();
        }, { once: true });
      } else {
        view.style.transform = '';
        view.addEventListener('transitionend', () => { view.style.transition = ''; }, { once: true });
      }
    }
    startX = null; tracking = false; dx = 0;
  }, { passive: true });
})();

$('btn-chat-menu').onclick = async () => {
  if (!S.chat) return;
  const { close, modal } = openModal(`
    <h3>会话设置</h3>
    <div class="row"><button class="btn-ghost" data-a="rename">重命名</button></div>
    <div class="row"><button class="btn-ghost" data-a="clear">清空并重新开始</button></div>
    <div class="row"><button class="btn-danger" data-a="delete">删除会话</button></div>
    <div class="row"><button class="btn-ghost" data-a="cancel">关闭</button></div>`);
  const act = async (a) => {
    close();
    const id = S.chat.id;
    if (a === 'rename') {
      const title = await promptModal('重命名会话', { textarea: false, initial: S.chat.session.title });
      if (title) {
        try {
          const s = await api(`/sessions/${id}`, { method: 'PATCH', body: JSON.stringify({ title }) });
          S.chat.session = s;
          renderChatHeader();
          loadSessions();
        } catch (e) { toast(e.message); }
      }
    } else if (a === 'clear') {
      if (await confirmModal('清空并重新开始', '将删除本会话全部消息，并重新发送开场白。', { danger: true, confirmText: '清空' })) {
        try {
          await api(`/sessions/${id}/messages`, { method: 'DELETE' });
          await reloadMessages();
          toast('已重新开始');
        } catch (e) { toast(e.message); }
      }
    } else if (a === 'delete') {
      if (await confirmModal('删除会话', '会话及其所有消息将被删除，无法恢复。', { danger: true, confirmText: '删除' })) {
        try {
          await api(`/sessions/${id}`, { method: 'DELETE' });
          $('btn-chat-back').click();
        } catch (e) { toast(e.message); }
      }
    }
  };
  modal.querySelectorAll('[data-a]').forEach((b) => { b.onclick = () => act(b.dataset.a); });
};

async function reloadMessages() {
  if (!S.chat) return;
  try {
    S.chat.messages = await api(`/sessions/${S.chat.id}/messages`);
  } catch (e) { toast(e.message); return; }
  renderMessages();
}

function renderMessages() {
  const box = $('messages');
  box.innerHTML = '';
  S.chat.messages.forEach((m) => box.appendChild(messageEl(m)));
  scrollBottom();
}

function messageEl(m) {
  const el = document.createElement('div');
  el.className = `msg ${m.role}`;
  el.dataset.id = m.id;

  if (m.role === 'assistant') {
    const av = document.createElement('span');
    av.className = 'avatar';
    const s = S.chat.session;
    avatarInto(av, s, s ? s.character_name : '');
    el.appendChild(av);
  }

  const body = document.createElement('div');
  body.className = 'msg-body';
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  bubble.innerHTML = md(m.content);
  body.appendChild(bubble);

  const ops = document.createElement('div');
  ops.className = 'msg-ops';
  const mini = (svg, title, fn) => {
    const b = document.createElement('button');
    b.className = 'mini-btn';
    b.title = title;
    b.innerHTML = svg;
    b.onclick = fn;
    return b;
  };
  const ICO = {
    left: '<svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="2" d="M14.5 6l-6 6 6 6"/></svg>',
    right: '<svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="2" d="M9.5 6l6 6-6 6"/></svg>',
    retry: '<svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.8" d="M21 12a9 9 0 1 1-2.6-6.4M21 4v5h-5"/></svg>',
    edit: '<svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.8" d="M4 20h4L19.5 8.5a2.1 2.1 0 0 0-3-3L5 17z"/></svg>',
    trash: '<svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.8" d="M4 7h16M9 7V5h6v2m-8 0 1 13h8l1-13"/></svg>',
    eye: '<svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.8" d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.6" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>',
    eyeOff: '<svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.8" d="M4 4l16 16M9.9 5.9A9.9 9.9 0 0 1 12 5.5c6 0 9.5 6.5 9.5 6.5a17.5 17.5 0 0 1-3.2 3.9M6.2 8A17 17 0 0 0 2.5 12S6 18.5 12 18.5c1 0 1.9-.2 2.7-.5"/></svg>',
  };

  const isLast = S.chat.messages[S.chat.messages.length - 1] === m;

  if (m.role === 'assistant' && m.swipes && m.swipes.length > 1) {
    const cnt = document.createElement('span');
    cnt.className = 'swipe-chip';
    cnt.textContent = `${m.selected + 1}/${m.swipes.length}`;
    ops.append(
      mini(ICO.left, '上一个备选', () => swipeMessage(m.id, 'prev')),
      cnt,
      mini(ICO.right, '下一个备选', () => swipeMessage(m.id, 'next')),
    );
  }
  if (m.role === 'assistant' && isLast && !m.is_greeting) {
    ops.appendChild(mini(ICO.retry, '重新生成', regenerate));
  }
  ops.appendChild(mini(ICO.edit, '编辑', () => editMessage(m)));
  ops.appendChild(mini(ICO.trash, '删除', () => deleteMessage(m)));
  body.appendChild(ops);

  el.appendChild(body);
  return el;
}

function scrollBottom() {
  const sc = $('chat-scroll');
  sc.scrollTop = sc.scrollHeight;
}

async function swipeMessage(id, direction) {
  if (S.generating) return;
  try {
    const r = await api(`/messages/${id}/swipe`, { method: 'POST', body: JSON.stringify({ direction }) });
    const m = S.chat.messages.find((x) => x.id === id);
    if (m) { m.selected = r.selected; m.content = m.swipes[r.selected]; }
    renderMessages();
  } catch (e) { toast(e.message); }
}

async function editMessage(m) {
  const content = await promptModal('编辑消息', { initial: m.content });
  if (content == null) return;
  try {
    await api(`/messages/${m.id}`, { method: 'PATCH', body: JSON.stringify({ content }) });
    await reloadMessages();
  } catch (e) { toast(e.message); }
}

async function deleteMessage(m) {
  if (!(await confirmModal('删除消息', '确定删除这条消息吗？', { danger: true, confirmText: '删除' }))) return;
  try {
    await api(`/messages/${m.id}`, { method: 'DELETE' });
    S.chat.messages = S.chat.messages.filter((x) => x.id !== m.id);
    renderMessages();
  } catch (e) { toast(e.message); }
}

/* ---------------- 生成流（SSE） ---------------- */

const composer = $('composer-input');
$('btn-send').onclick = () => (S.generating ? stopGenerate() : send());

composer.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
    e.preventDefault();
    if (!S.generating) send();
  }
});
composer.addEventListener('input', () => {
  composer.style.height = 'auto';
  composer.style.height = Math.min(composer.scrollHeight, 140) + 'px';
});

function setGenerating(on) {
  S.generating = on;
  const btn = $('btn-send');
  btn.classList.toggle('stop', on);
  btn.title = on ? '停止' : '发送';
  btn.innerHTML = on
    ? '<svg viewBox="0 0 24 24"><rect x="7" y="7" width="10" height="10" rx="2" fill="currentColor"/></svg>'
    : '<svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.8" d="M4 12 20 4l-4 8 4 8z"/></svg>';
}

function stopGenerate() {
  if (S.abort) S.abort.abort();
}

async function send() {
  const text = composer.value.trim();
  if (!text || !S.chat) return;
  composer.value = '';
  composer.style.height = 'auto';

  // 乐观插入用户消息
  S.chat.messages.push({ id: -1, role: 'user', content: text, swipes: [text], selected: 0 });
  $('messages').appendChild(messageEl(S.chat.messages[S.chat.messages.length - 1]));
  scrollBottom();

  await streamChat(`/sessions/${S.chat.id}/chat`, { content: text });
}

async function regenerate() {
  if (S.generating || !S.chat) return;
  await streamChat(`/sessions/${S.chat.id}/regenerate`, {});
}

async function streamChat(path, body) {
  setGenerating(true);
  const ac = new AbortController();
  S.abort = ac;

  let streamEl = null;
  let streamBubble = null;
  const startStreamBubble = () => {
    streamEl = document.createElement('div');
    streamEl.className = 'msg assistant';
    const s = S.chat.session;
    const av = document.createElement('span');
    av.className = 'avatar';
    avatarInto(av, s, s ? s.character_name : '');
    streamBubble = document.createElement('div');
    streamBubble.className = 'msg-body';
    streamBubble.innerHTML = '<div class="bubble streaming"></div>';
    streamEl.append(av, streamBubble);
    streamEl.querySelector('.bubble').textContent = '…';
    $('messages').appendChild(streamEl);
    scrollBottom();
  };
  const removeStreamBubble = () => {
    if (streamEl && streamEl.parentNode) streamEl.parentNode.removeChild(streamEl);
    streamEl = null;
  };

  try {
    const res = await fetch('/api' + path, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: ac.signal,
    });
    if (!res.ok) {
      const d = await res.json().catch(() => ({}));
      throw new Error(d.error || `请求失败（${res.status}）`);
    }
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let idx;
      while ((idx = buf.indexOf('\n\n')) >= 0) {
        const frame = buf.slice(0, idx);
        buf = buf.slice(idx + 2);
        let ev = 'message', data = '{}';
        for (const line of frame.split('\n')) {
          if (line.startsWith('event:')) ev = line.slice(6).trim();
          else if (line.startsWith('data:')) data = line.slice(5).trim();
        }
        if (ev === 'start') startStreamBubble();
        else if (ev === 'delta' && streamEl) {
          streamEl.querySelector('.bubble').textContent = JSON.parse(data).text;
          scrollBottom();
        } else if (ev === 'done') { /* 重载后展示 */ }
        else if (ev === 'error') { throw new Error(JSON.parse(data).message || '生成失败'); }
      }
    }
  } catch (e) {
    if (e.name !== 'AbortError') toast(e.message);
  } finally {
    removeStreamBubble();
    setGenerating(false);
    S.abort = null;
    await reloadMessages();
    loadSessions();
  }
}

/* ---------------- 记忆池 ---------------- */

async function loadMemories(charId) {
  let id = charId || S.memCharId;
  if (id == null) {
    try {
      const chars = await api('/characters');
      S.characters = chars;
      if (!chars.length) { renderMemories(); return; }
      S.memCharId = id = (S.homeCharId != null && chars.some((c) => c.id === S.homeCharId)) ? S.homeCharId : chars[0].id;
    } catch (e) { toast(e.message); return; }
  }
  S.memCharId = id;
  try {
    S.memories = await api(`/characters/${id}/memories`);
  } catch (e) { toast(e.message); return; }
  renderMemories();
}

function renderMemories() {
  const chips = $('mem-chips');
  chips.innerHTML = '';
  const chars = S.characters;
  if (!chars.length) {
    chips.innerHTML = '<span class="muted">还没有角色，先到「我的」导入角色卡。</span>';
  }
  chars.forEach((c) => {
    const b = document.createElement('button');
    b.className = 'chip' + (c.id === S.memCharId ? ' active' : '');
    const av = document.createElement('span');
    av.className = 'avatar small';
    avatarInto(av, c);
    b.append(av, document.createTextNode(c.nickname || c.name));
    b.onclick = () => loadMemories(c.id);
    chips.appendChild(b);
  });

  const enabled = S.memories.filter((m) => m.enabled).length;
  $('mem-count').textContent = S.memories.length ? `${enabled} 条生效 / 共 ${S.memories.length} 条` : '';

  const list = $('memory-list');
  list.innerHTML = '';
  if (!S.memories.length) {
    list.innerHTML = `<div class="list-empty">记忆池还是空的。<br>手动记一条，或从聊天里自动总结。</div>`;
    return;
  }
  const ICO = {
    edit: '<svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.8" d="M4 20h4L19.5 8.5a2.1 2.1 0 0 0-3-3L5 17z"/></svg>',
    trash: '<svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.8" d="M4 7h16M9 7V5h6v2m-8 0 1 13h8l1-13"/></svg>',
    eye: '<svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.8" d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.6" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>',
    eyeOff: '<svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.8" d="M4 4l16 16M9.9 5.9A9.9 9.9 0 0 1 12 5.5c6 0 9.5 6.5 9.5 6.5a17.5 17.5 0 0 1-3.2 3.9M6.2 8A17 17 0 0 0 2.5 12S6 18.5 12 18.5c1 0 1.9-.2 2.7-.5"/></svg>',
  };
  S.memories.forEach((m) => {
    const item = document.createElement('div');
    item.className = 'memory-item' + (m.enabled ? '' : ' disabled');
    const p = document.createElement('p');
    p.textContent = m.content;
    const tag = document.createElement('span');
    tag.className = 'tag';
    tag.textContent = m.source === 'auto' ? 'AI总结' : '手动';
    const ops = document.createElement('div');
    ops.className = 'ops';
    const mk = (html, title, fn) => {
      const b = document.createElement('button');
      b.className = 'mini-btn';
      b.title = title;
      b.innerHTML = html;
      b.onclick = fn;
      return b;
    };
    ops.append(
      mk(m.enabled ? ICO.eyeOff : ICO.eye, m.enabled ? '暂停（不注入对话）' : '启用', () => toggleMemory(m)),
      mk(ICO.edit, '编辑', () => editMemory(m)),
      mk(ICO.trash, '删除', () => deleteMemory(m)),
    );
    item.append(p, tag, ops);
    list.appendChild(item);
  });
}

async function toggleMemory(m) {
  try {
    const r = await api(`/memories/${m.id}`, { method: 'PATCH', body: JSON.stringify({ enabled: !m.enabled }) });
    Object.assign(m, r);
    renderMemories();
  } catch (e) { toast(e.message); }
}

async function editMemory(m) {
  const content = await promptModal('编辑记忆', { initial: m.content });
  if (content == null) return;
  try {
    await api(`/memories/${m.id}`, { method: 'PATCH', body: JSON.stringify({ content }) });
    await loadMemories();
  } catch (e) { toast(e.message); }
}

async function deleteMemory(m) {
  if (!(await confirmModal('删除记忆', '这条记忆将从记忆池移除。', { danger: true, confirmText: '删除' }))) return;
  try {
    await api(`/memories/${m.id}`, { method: 'DELETE' });
    S.memories = S.memories.filter((x) => x.id !== m.id);
    renderMemories();
  } catch (e) { toast(e.message); }
}

$('btn-mem-add').onclick = async () => {
  if (S.memCharId == null) return toast('先导入一个角色');
  const content = await promptModal('记一条记忆', { placeholder: '例如：用户习惯熬夜，喜欢在深夜聊天' });
  if (content == null) return;
  try {
    await api(`/characters/${S.memCharId}/memories`, { method: 'POST', body: JSON.stringify({ content }) });
    await loadMemories();
    toast('已加入记忆池');
  } catch (e) { toast(e.message); }
};

$('btn-mem-summarize').onclick = async () => {
  if (S.memCharId == null) return toast('先导入一个角色');
  const btn = $('btn-mem-summarize');
  btn.disabled = true;
  btn.textContent = '正在总结…';
  try {
    const r = await api(`/characters/${S.memCharId}/remember`, { method: 'POST' });
    if (r.added && r.added.length) toast(`总结了 ${r.added.length} 条新记忆`);
    else toast('没有发现值得新记的内容');
    await loadMemories();
  } catch (e) { toast(e.message); }
  btn.disabled = false;
  btn.textContent = '从最近对话总结记忆';
};

/* ---------------- 我的 / 设置 ---------------- */

async function loadSettings() {
  try {
    S.settings = await api('/settings');
  } catch (e) { return; }
  const s = S.settings;
  $('me-persona-name').value = s.persona_name || '';
  $('me-persona-desc').value = s.persona_description || '';
  $('me-api-base').value = s.api_base || '';
  $('me-model').value = s.model || '';
  $('me-temp').value = s.temperature;
  $('me-temp-val').textContent = s.temperature;
  $('me-ctx').value = s.context_messages;
  $('me-mem-interval').value = s.memory_interval;
  $('me-api-key').value = '';
  $('me-api-key').placeholder = s.api_key_preview ? `已保存 ${s.api_key_preview}（留空不修改）` : '未设置';
  $('me-key-status').textContent = '';
}

$('me-temp').addEventListener('input', () => { $('me-temp-val').textContent = $('me-temp').value; });

/* 设置自动保存：停止输入 1 秒后自动提交（API Key 例外，只走手动保存避免存半截） */
let meSaveTimer = null;
async function saveMeSettings(showToast) {
  const body = {
    persona_name: $('me-persona-name').value.trim() || 'User',
    persona_description: $('me-persona-desc').value.trim(),
    api_base: $('me-api-base').value.trim(),
    model: $('me-model').value.trim(),
    temperature: Number($('me-temp').value),
    context_messages: Number($('me-ctx').value),
    memory_interval: Number($('me-mem-interval').value),
  };
  const key = $('me-api-key').value.trim();
  if (key) body.api_key = key;
  try {
    await api('/settings', { method: 'PUT', body: JSON.stringify(body) });
    if (showToast) { toast('已保存'); await loadSettings(); }
    else {
      const st = $('me-key-status');
      st.textContent = '✓ 已自动保存';
      setTimeout(() => { st.textContent = ''; }, 2000);
    }
  } catch (e) { toast(e.message); }
}

function scheduleMeSave() {
  clearTimeout(meSaveTimer);
  meSaveTimer = setTimeout(() => saveMeSettings(false), 1000);
}

['me-persona-name', 'me-persona-desc', 'me-api-base', 'me-model', 'me-ctx', 'me-mem-interval'].forEach((id) => {
  $(id).addEventListener('input', scheduleMeSave);
});
$('me-temp').addEventListener('change', scheduleMeSave);
// 人设框自动增高
$('me-persona-desc').addEventListener('input', function () {
  this.style.height = 'auto';
  this.style.height = Math.min(Math.max(this.scrollHeight, 130), 320) + 'px';
});

$('btn-save-me').onclick = () => saveMeSettings(true);

$('btn-clear-key').onclick = async () => {
  if (!(await confirmModal('清除 API Key', '清除后将无法调用模型，直到重新填写。', { danger: true, confirmText: '清除' }))) return;
  try {
    await api('/settings', { method: 'PUT', body: JSON.stringify({ clear_api_key: true }) });
    toast('已清除');
    loadSettings();
  } catch (e) { toast(e.message); }
};

$('btn-logout').onclick = async () => {
  if (!(await confirmModal('退出登录', '返回登录页。', { confirmText: '退出' }))) return;
  try { await api('/logout', { method: 'POST' }); } catch { /* ignore */ }
  location.reload();
};

async function loadCharacters() {
  try { S.characters = await api('/characters'); } catch (e) { return; }
  const list = $('me-char-list');
  list.innerHTML = '';
  if (!S.characters.length) {
    list.innerHTML = '<span class="muted">还没有角色</span>';
    return;
  }
  S.characters.forEach((c) => {
    const row = document.createElement('div');
    row.className = 'me-char-row';
    const av = document.createElement('span');
    av.className = 'avatar small';
    avatarInto(av, c);
    const name = document.createElement('span');
    name.textContent = c.nickname || c.name;
    const del = document.createElement('button');
    del.className = 'mini-btn';
    del.title = '删除角色';
    del.innerHTML = '<svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.8" d="M4 7h16M9 7V5h6v2m-8 0 1 13h8l1-13"/></svg>';
    del.onclick = async () => {
      if (!(await confirmModal(`删除角色「${c.name}」`, '其所有会话、消息和记忆都会一并删除。', { danger: true, confirmText: '删除' }))) return;
      try {
        await api(`/characters/${c.id}`, { method: 'DELETE' });
        toast('已删除');
        await loadCharacters();
        S.homeCharId = null;
        await loadHome();
      } catch (e) { toast(e.message); }
    };
    row.append(av, name, del);
    list.appendChild(row);
  });
}

$('btn-import').onclick = () => $('file-input').click();

$('file-input').addEventListener('change', async () => {
  const file = $('file-input').files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append('file', file);
  try {
    const r = await api('/characters/import', { method: 'POST', body: fd });
    toast(`已导入角色「${r.name}」（${r.spec.toUpperCase()} 卡）`);
    await loadCharacters();
    S.homeCharId = r.id;
    await loadHome();
    switchTab('home');
  } catch (e) {
    toast(e.message);
  } finally {
    $('file-input').value = '';
  }
});

/* ---------------- 主题 ---------------- */

const THEMES = [
  { id: 'dusk', name: '黄昏', sw: 'linear-gradient(135deg,#e4d7bf,#4d5f4d)' },
  { id: 'night', name: '深夜', sw: 'linear-gradient(135deg,#1e2836,#0a0e16)' },
  { id: 'sakura', name: '樱雨', sw: 'linear-gradient(135deg,#f9dfe4,#75526a)' },
  { id: 'pine', name: '松间', sw: 'linear-gradient(135deg,#dcecdd,#3a6449)' },
  { id: 'sky', name: '晴空', sw: 'linear-gradient(135deg,#d7e9f6,#44708f)' },
];

function applyTheme(preset) {
  if (THEMES.some((t) => t.id === preset)) {
    document.documentElement.dataset.theme = preset;
    localStorage.setItem('cs_theme', preset);
  }
}

// 应用背景状态（type: 'image' | 'video' | null）
function applyBg(type) {
  document.body.classList.toggle('has-bg-img', type === 'image');
  document.body.classList.toggle('has-bg-video', type === 'video');
  const img = $('bg-img'), video = $('bg-video');
  if (type === 'image') {
    img.src = `/api/theme/bg?t=${Date.now()}`;
    video.removeAttribute('src');
  } else if (type === 'video') {
    video.src = `/api/theme/bg-video?t=${Date.now()}`;
    img.removeAttribute('src');
    video.play().catch(() => { /* 自动播放失败时静默，用户交互后 loop 会恢复 */ });
  } else {
    img.removeAttribute('src');
    video.removeAttribute('src');
    video.pause();
  }
}

async function loadTheme() {
  // cookie 在 HTML 响应中已带上，同步读取立即应用；再向服务器确认一次
  const fromCookie = (document.cookie.match(/(?:^|;\s*)cs_bg=(image|video|none)/) || [])[1] || null;
  if (fromCookie === 'image' || fromCookie === 'video') {
    applyBg(fromCookie);
    if (fromCookie === 'image') $('bg-img').src = '/api/theme/bg';
    if (fromCookie === 'video') $('bg-video').src = '/api/theme/bg-video';
  }
  try {
    const t = await fetch('/api/theme').then((r) => r.json());
    applyTheme(t.preset);
    applyBg(t.bg);
    if (t.bg === 'image') $('bg-img').src = '/api/theme/bg';
    if (t.bg === 'video') $('bg-video').src = '/api/theme/bg-video';
  } catch {
    applyTheme(localStorage.getItem('cs_theme') || 'dusk');
  }
}

function renderThemeUI(current) {
  const row = $('theme-row');
  row.innerHTML = '';
  THEMES.forEach((t) => {
    const b = document.createElement('button');
    b.className = 'theme-dot' + (t.id === current ? ' active' : '');
    b.innerHTML = `<span class="swatch" style="background:${t.sw}"></span><span>${t.name}</span>`;
    b.onclick = async () => {
      applyTheme(t.id);
      renderThemeUI(t.id);
      try {
        await api('/theme', { method: 'PUT', body: JSON.stringify({ preset: t.id }) });
      } catch (e) { toast(e.message); }
    };
    row.appendChild(b);
  });
}

async function initThemeUI() {
  try {
    const t = await api('/theme');
    renderThemeUI(t.preset);
    applyBg(t.bg);
    localStorage.setItem('cs_bg', JSON.stringify(t.bg));
    if (t.bg === 'image') $('bg-img').src = `/api/theme/bg?t=${Date.now()}`;
    if (t.bg === 'video') $('bg-video').src = `/api/theme/bg-video?t=${Date.now()}`;
  } catch { /* ignore */ }
}

$('btn-bg-upload').onclick = () => $('bg-input').click();
$('bg-input').addEventListener('change', async () => {
  const file = $('bg-input').files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append('bg', file);
  fd.append('preset', document.documentElement.dataset.theme || 'dusk');
  try {
    const r = await api('/theme', { method: 'PUT', body: fd });
    toast(r.bg === 'video' ? '视频背景已生效' : '背景已更新');
    localStorage.setItem('cs_bg', JSON.stringify(r.bg));
    applyBg(r.bg);
    if (r.bg === 'video') $('bg-video').src = `/api/theme/bg-video?t=${Date.now()}`;
    if (r.bg === 'image') $('bg-img').src = `/api/theme/bg?t=${Date.now()}`;
  } catch (e) { toast(e.message); }
  $('bg-input').value = '';
});
$('btn-bg-clear').onclick = async () => {
  try {
    await api('/theme', { method: 'PUT', body: JSON.stringify({ clear_bg: '1' }) });
    localStorage.setItem('cs_bg', JSON.stringify(null));
    applyBg(null);
    toast('已恢复默认风景');
  } catch (e) { toast(e.message); }
};

/* ---------------- 主动消息 ---------------- */

async function loadProactive() {
  try {
    const p = await api('/proactive');
    $('pro-enabled').checked = p.enabled;
    $('pro-times').value = p.times;
    $('pro-random').checked = p.random;
  } catch { /* ignore */ }
  // 可选角色
  const sel = $('pro-char');
  sel.innerHTML = '';
  try {
    const chars = S.characters.length ? S.characters : await api('/characters');
    chars.forEach((c) => {
      const o = document.createElement('option');
      o.value = c.id;
      o.textContent = c.nickname || c.name;
      sel.appendChild(o);
    });
  } catch { /* ignore */ }
  // 能力提示
  if (!window.isSecureContext) {
    $('pro-hint').textContent = '当前是 HTTP 访问，浏览器不允许开启通知。给域名配好 HTTPS 后，这里就能开启。';
    $('btn-pro-notify').disabled = true;
  }
}

$('btn-pro-save').onclick = async () => {
  try {
    await api('/proactive', {
      method: 'PUT',
      body: JSON.stringify({
        enabled: $('pro-enabled').checked,
        random: $('pro-random').checked,
        times: $('pro-times').value,
      }),
    });
    toast('已保存');
  } catch (e) { toast(e.message); }
};

$('btn-pro-notify').onclick = async () => {
  try {
    if (!window.isSecureContext) return toast('需要 HTTPS 才能开启通知');
    const perm = await Notification.requestPermission();
    if (perm !== 'granted') return toast('没有获得通知权限');
    const reg = await navigator.serviceWorker.ready;
    const { publicKey } = await api('/push/key');
    const b64ToU8 = (b64) => {
      const pad = '='.repeat((4 - (b64.length % 4)) % 4);
      const raw = atob((b64 + pad).replace(/-/g, '+').replace(/_/g, '/'));
      return Uint8Array.from(raw, (c) => c.charCodeAt(0));
    };
    let sub = await reg.pushManager.getSubscription();
    if (!sub) {
      sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToU8(publicKey) });
    }
    await api('/push/subscribe', {
      method: 'POST',
      body: JSON.stringify({ subscription: sub.toJSON(), character_id: Number($('pro-char').value) }),
    });
    toast('手机通知已开启');
  } catch (e) { toast(e.message); }
};

$('btn-pro-test').onclick = async () => {
  try {
    await api('/push/test', { method: 'POST', body: JSON.stringify({ character_id: Number($('pro-char').value) }) });
    toast('测试通知已发出（手机要允许站点通知）');
  } catch (e) { toast(e.message); }
};

/* ---------------- 启动动画 ---------------- */

function hideSplash() {
  const splash = $('splash');
  if (!splash || splash.classList.contains('splash-leave')) return;
  splash.classList.add('splash-leave');
  setTimeout(() => splash.remove(), 700);
}

function startSplash() {
  const splashVideo = $('splash-video');
  if (localStorage.getItem('cs_bg') === '"video"') {
    splashVideo.src = '/api/theme/bg-video';
    splashVideo.play().catch(() => {});
  }
  const minShow = new Promise((res) => setTimeout(res, 1100));
  const ready = document.readyState === 'complete' ? Promise.resolve() : new Promise((res) => window.addEventListener('load', res, { once: true }));
  Promise.all([minShow, ready]).then(hideSplash);
  // 兜底：无论如何 4 秒后必消失
  setTimeout(hideSplash, 4000);
}

/* ---------------- 启动 ---------------- */

startSplash();
boot();
